<!doctype html>
<html>
<head>
<meta charset="UTF-8">
	<title>Gestion des personnels</title>
	
</head>
<body>



@include('layouts.sidebar')
           

</body>
</html>
