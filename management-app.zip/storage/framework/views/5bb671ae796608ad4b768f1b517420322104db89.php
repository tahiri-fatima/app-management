
  
<?php $__env->startSection('content'); ?>

<div class="container" style="margin-left: 20%;" > 
        <a class="btn btn-outline-primary text-right" href="<?php echo e(route('operations.create')); ?>"><i class="fa fa-fw fa-plus-circle"></i> Ajouter nouvelle opération</a> 
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit')): ?>
        <a class="btn btn-outline-primary"  href="<?php echo e(route('operations.edit',$operation->id)); ?>" ><i class="fa fa-fw fa-edit"></i> Modifier</a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete')): ?>
        <button type="submit" class="btn btn-outline-primary" onclick="$('#modal').modal('show');"  ><i class="fa fa-fw fa-trash"></i> Supprimer</button>
        <?php endif; ?>
        <a class="btn btn-outline-primary" href="<?php echo e(route('operations.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div>

<!-- modal pour confirmer la supression !-->
<div   class="modal" tabindex="-1" role="dialog" id="modal" >
  <div class="modal-dialog" role="document" >
  <form class="modal-content"action="<?php echo e(route('operations.destroy',$operation->id)); ?>" method="POST">
      <div class="modal-header" >
        <h5 class="modal-title" style="color:red;" > Confirmation de la supprission</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
          <strong >
            
            <p>Voulez vous supprimer l'opération dont le code <?php echo e($operation->code_operation); ?> ?</p>
        </strong>
      </div>
      <div class="modal-footer">
     
        <button type="button" data-dismiss="modal" class="btn btn-outline-secondary" > Annuler</button>
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit"  class="btn btn-outline-danger"> Supprimer</button>
      </div>
  </form>
    </div>
  </div>

<div class="col d-flex justify-content-center"> 

<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success message">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
</div>
<div class="col d-flex justify-content-center">

<div class="col-xl-6 col-md-12 ">
    <div class="card table-card">

         <div class="card-header">
            <h5>Détails d'opération</h5>
                <div class="card-header-right">
                    <ul class="list-unstyled card-option">
                        <li><i class="fa fa fa-wrench open-card-option"></i></li>
                        <li><i class="fa fa-window-maximize full-card"></i></li>
                        <li><i class="fa fa-minus minimize-card"></i></li>
                     </ul>
                </div>
            </div>
            
            <div class="card-block">
                <div class="table-responsive">
                    <table class="table table-hover m-b-0 without-header">
                        <tbody>
                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Code d'opération : </h6> 
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6> <?php echo e($operation->code_operation); ?></h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Désignation d'opération : </h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6> <?php echo e($operation->designation_operation); ?></h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                           

                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Unité : </h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>  <?php echo e($operation->unite); ?></h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                           
                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Sous traitance :</h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($soutraitance->intitule_soutraitance); ?></h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                 </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('operations.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/operations/show.blade.php ENDPATH**/ ?>