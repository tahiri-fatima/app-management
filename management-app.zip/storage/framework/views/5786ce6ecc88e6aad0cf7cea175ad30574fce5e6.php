
   
<?php $__env->startSection('content'); ?>

   
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('reparations.show',$reparation->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 
   
<div class="col justify-content-center" >

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<!-- Alert si le code est dupliqué !-->
<?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un réparation avec ce code de réparation.<br><br>
            
        </div>
<?php endif; ?>
</div>


<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:70%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-edit"></i>  Modifier la réparation</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold; ">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

        <form class="form-material" action="<?php echo e(route('reparations.update',$reparation->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

            <div class="row justify-content-around">
                 <div class="col-6">
                 <label style="top: -14px; font-size: 11px; color: #448aff;">Code de la réparation<span class="text-danger">*</span> </label>
                    <div class="form-group form-primary form-static-label">
                        <input type="text" name="code_reparation" value="<?php echo e($reparation->code_reparation); ?>" class="form-control" placeholder="Entrer le code de la réparation">
                    </div>
                 </div>
                 <div class="col-6">
                 <label style="top: -14px; font-size: 11px; color: #448aff;">Intitulé de la réparation<span class="text-danger">*</span> </label>
                    <div class="form-group form-primary form-static-label">
                        <input type="text" name="intitule_reparation" value="<?php echo e($reparation->intitule_reparation); ?>" class="form-control" placeholder="Entrer l'intitulé de la réparation'">
                    </div>
                 </div>
            </div>

                <div class="row justify-content-around">
                     <div class="col-6">
                     <label style="top: -14px; font-size: 11px; color: #448aff;">Montant de la réparation<span class="text-danger">*</span> </label>
                        <div class="form-group form-primary form-static-label">
                            <input type="double" name="montant_reparation" value="<?php echo e($reparation->montant_reparation); ?>" class="form-control" placeholder="Entrer le montant de la réparation">
                        </div>
                     </div>
                     <div class="col-6">
                     <label style="top: -14px; font-size: 11px; color: #448aff;">Date de la réparation<span class="text-danger">*</span> </label>
                        <div class="form-group form-primary form-static-label">
                            <input type="date" name="date_reparation" value="<?php echo e($reparation->date_reparation); ?>" class="form-control" >
                        </div>
                     </div>
                </div>
                
                     <div class="row">
                     <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <label  style="top: -14px; font-size: 11px; color: #448aff;">Matériel <span class="text-danger">*</span> </label>
                                <div class="select">
                                <select class="form-control" name="materiel_id">
                                <option value="<?php echo e($materiel->id); ?>"><?php echo e($materiel->intitule_materiel); ?></option>
                                    <?php $__currentLoopData = $materiels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materiel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($materiel->id); ?>"><?php echo e($materiel->intitule_materiel); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div> 
                         </div>
                    </div>
                     </div>
               
                    <div class=" text-right">
                        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
                    </div>
                                                                    
            </form>
         </div>
    </div>

<!-- end Formulaire -->


    <!-- formulaire 
    <div class="card">

<div class="card-header"><strong> Modifier la réparation</strong> </div>

    <div class="card-body">
        
        <div class="col-sm-8">

<form action="<?php echo e(route('reparations.update',$reparation->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>

    <div class="row justify-content-around">
        <div class="col-6">
            <div class="form-group">
            <label > <strong>Code : <span class="text-danger">*</span></strong></label>
                <input type="text" name="codereparation" value="<?php echo e($reparation->codereparation); ?>" class="form-control" placeholder="Code">
            </div>
        </div>

        <div class="col-6">
                <div class="form-group">
                <label > <strong>Intitulé : <span class="text-danger">*</span></strong></label>
                    <input type="text" class="form-control" name="intitulereparation" value="<?php echo e($reparation->intitulereparation); ?>" placeholder="Intitulé réparation">
                </div>
        </div>
    </div>

    <div class="row justify-content-around">
        <div class="col-6">
            <div class="form-group">
            <label > <strong>Montant de la réparation : <span class="text-danger">*</span></strong></label>
                <input type="decimal" class="form-control" name="montantreparation" value="<?php echo e($reparation->montantreparation); ?>" placeholder="Montant réparation">
            </div>
        </div>
        
        <div class="col-6">
            <div class="form-group">
            <label> <strong>Date de la réparation : <span class="text-danger">*</span></strong></label>
                <input type="date" class="form-control" name="datereparation" value="<?php echo e($reparation->datereparation); ?>" placeholder="Date reparation">
            </div>
        </div>
    </div>

    <div class="row">
    <div class="col-6">
                <div class="form-group">
                    <label ><strong>Matériel : <span class="text-danger">*</span></strong></label>
                    <div class="select">
                    <select class="form-control" name="materiel_id" >
                        <option value="<?php echo e($materiel->id); ?>"><?php echo e($materiel->intitulemateriel); ?></option>
                        <?php $__currentLoopData = $materiels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materiel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($materiel->id); ?>"><?php echo e($materiel->intitulemateriel); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>
                </div>
        </div>
    </div>

<div class=" text-right">
        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
</div>
</div>

</form>
</div>
    </div>
</div>
!-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('reparations.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/reparations/edit.blade.php ENDPATH**/ ?>