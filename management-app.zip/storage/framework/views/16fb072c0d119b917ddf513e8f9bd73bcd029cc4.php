<!doctype html>
<html>
<head>
<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Fournisseurs</title>
	
	</head>
<body>




<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/fournisseurs/layout.blade.php ENDPATH**/ ?>