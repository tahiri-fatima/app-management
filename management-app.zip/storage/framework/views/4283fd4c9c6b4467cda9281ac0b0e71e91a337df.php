
 
<?php $__env->startSection('content'); ?>


<!-- Alert si le code est dupliqué !-->
<?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> N'éxiste aucun entretien avec les informations de la recherche !<br><br>
        </div>
<?php endif; ?>
  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('entretiens.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 
	
<div class="col  justify-content-center">    

<div class="blog-header py-1">
				<h3>Résultat de la recherche </h3>
</div>
		<div>
     
			<table class="table table-striped table-bordered text-center">
				<thead>
                <tr class="bg-primary text-white">
						<th >Code d'entretien</th>
						<th >Intitulé d'entretien</th>
						<th >Action</th>
					</tr>
				</thead>
				<tbody>
                <?php $__currentLoopData = $entretiens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entretien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($entretien->code_entretien); ?></td>
            <td><?php echo e($entretien->intitule_entretien); ?></td>
            <td>
                <a class="btn btn-info" href="<?php echo e(route('entretiens.show',$entretien->id)); ?>" style="margin-left: 15px;"><i class="fa fa-fw fa-eye"></i>Consulter</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div> <!--/.col-sm-12-->
		

</div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('entretiens.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/entretiens/search.blade.php ENDPATH**/ ?>