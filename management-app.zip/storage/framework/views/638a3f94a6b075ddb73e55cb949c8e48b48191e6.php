
 
<?php $__env->startSection('content'); ?>

<div class="container " style="margin-left: 200px;">  

			<div class="card-body">
                <div>
					<h5 class="card-title"><i class="fa fa-fw fa-search"></i> Chercher fournisseur</h5>

                        <form class="form-material" type="get" action="<?php echo e(route('fournisseurs.search')); ?>" >
                        <div class="row d-flex justify-content-around">
                                <div class="col-4">
                                <div class="form-group" style="margin-right: 15px;" >
                                    <input class="form-control mr-ms-2" name="code_fournisseur"  type="search" placeholder="Code du fournisser" >
                                </div>
                                </div>
                                <div class="col-4">
                                <div class="form-group" style="margin-right: 15px;" >
                                    <input class="form-control mr-ms-2" name="intitule_fournisseur"  type="search" placeholder="Intitulé du fournisser" >
                                </div>
                                </div>
                                <div class="row pull-right" style="margin-right: 15px;">
                                <div class="form-group "  >
                                    <button class="btn btn-primary" type="submit" value="search" style="margin-right: 15px;" ><i class="fa fa-fw fa-search"></i> Chercher</button>
                                    <button type="reset" class="btn btn-info" > <i class="fa fa-fw fa-sync"></i> Réinitialiser</button>
                                </div>
                                </div>
                        </div>
                        </form>
                </div>
            </div>
        </div>
</div>


<div class="form-material" style="margin-top: 20px;margin-bottom: 20px">
		<div class="" style="margin-bottom: 20px;">
			
        <div class="text-right" style="margin-right:100px"> 
            <a class="btn btn-primary " href="home" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
        </div> 

		</div> <!--/.container-->


        <div class="col d-flex justify-content-center ">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success message">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <?php if($message = Session::get('warning')): ?>
        <div class="alert alert-info message">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        </div>

        <div class="col  justify-content-center ">
        <h5 class="m-b-20 m-l-50" >Sélectionner un fournisseur pour afficher ses commandes</h5>

        <div class="row " style="margin-left: 50px;" >
            <div class="col-6">
                <div class="form-group form-primary form-static-label">
                    <select class="form-control" id="fournisseurs" type="dropdown-toggle" class="form-control" name="fournisseurs" onchange="top.location.href = this.options[this.selectedIndex].value" >
                        <option value="choisir" selected disabled>Choisir fournisseur</option>
                        <?php $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="fournisseurs" value="<?php echo e(route('fournisseurs.getCommandes',$fournisseur->id)); ?>"><?php echo e($fournisseur->intitule_fournisseur); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>                
                <span class="form-bar"></span>
                     
            </div>
        </div>


</div>
	

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/edition/listeCommandesFournisseur.blade.php ENDPATH**/ ?>