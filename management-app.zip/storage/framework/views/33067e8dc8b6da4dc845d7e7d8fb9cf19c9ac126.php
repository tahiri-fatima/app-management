


  
<?php $__env->startSection('content'); ?>
   
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('soutraitances.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col d-flex justify-content-center" >

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un enregistrement avec ce code de sous traitance.<br><br>
            
        </div>
    <?php endif; ?>

<!-- Affichage de modal si l'enregistrement ajouté avec succes. !-->
    <?php if(!empty(Session::get('success')) && Session::get('success') == 'soutraitance ajouté avec succes.'): ?>
    <script>
        $(function() {
            $('#myModal').modal('show');
        });
    </script>
    <?php endif; ?>

<!-- modal si soutraitance ajouté avec succes !-->
<div class="modal" tabindex="-1" role="dialog" id="myModal" >
  <div class="modal-dialog" role="document" >
    <div class="modal-content">
      <div class="modal-header" >
        <h5 class="modal-title" style="color:#228B22;" > Ajout avec succes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
          <strong >
            <p>Enregistrement ajouté avec succes.</p>
            <p>Voulez vous insérer un autre enregistrement ?</p>
        </strong>
      </div>
      <div class="modal-footer">
        <a class="btn btn-outline-secondary" href="<?php echo e(route('soutraitances.index')); ?>"> Non</a>
        
        <button type="button" class="btn btn-outline-success" data-dismiss="modal">Oui</button>
      </div>
    </div>
  </div>
</div>
</div>

<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:50%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-plus-circle"></i>  Ajouter nouveau sous traitance</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold; margin-bottom : 30px;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

            <form class="form-material" action="<?php echo e(route('soutraitances.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
                <div class="form-group form-primary form-static-label">
                    <input type="text" name="code_soutraitance" class="form-control" placeholder="Entrer le code de sous traitance">
                    <span class="form-bar"></span>
                    <label class="float-label">Code de sous traitance<span class="text-danger">*</span> </label>
                </div>

                <div class="form-group form-primary form-static-label">
                    <input type="text" name="intitule_soutraitance" class="form-control" placeholder="Entrer l'intitulé de sous traitance">
                    <span class="form-bar"></span>
                    <label class="float-label">Intitulé de sous traitance<span class="text-danger">*</span> </label>
                    
                </div>

                <div class="form-group form-primary form-static-label">
                    <input type="double" name="montant_soutraitance" class="form-control" placeholder="Entrer le montant de sous traitance">
                    <span class="form-bar"></span>
                    <label class="float-label">Montant de sous traitance<span class="text-danger">*</span> </label>
                </div>

                <div class="form-group form-primary form-static-label">
                    <input type="date" name="date_soutraitance" class="form-control">
                    <span class="form-bar"></span>
                    <label class="float-label">Date de sous traitance <span class="text-danger">*</span> </label>
                </div>


                <div class=" text-right" style="margin-top: 10px;">
                <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-plus-circle"> </i> Ajouter</button>
                <button type="reset" class="btn btn-info" style="margin-left: 10px;"><i class="fa fa-fw fa-sync" ></i> Réinitialiser</button>
                 </div>
                                                 
            </form>
         </div>
    </div>

<!-- end Formulaire -->

<!-- formulaire 
<div class="card">

		<div class="card-header"><i class="fa fa-fw fa-plus-circle"></i> <strong> Ajouter nouveau sous traitance</strong> </div>

			<div class="card-body">
                
				<div class="col-sm-8">

<form action="<?php echo e(route('soutraitances.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
    <div class="row justify-content-around" >
        <div class="col-6">
            <div class="form-group">
                <strong>Code : <span class="text-danger">*</span></strong>
                <input type="text" name="codesou_traitance" class="form-control" placeholder="Code">
            </div>
        </div>

        <div class="col-6">
            <div class="form-group">
                <strong>Intitulé : <span class="text-danger">*</span></strong>
                <input type="text" class="form-control" name="intitulesou_traitance" placeholder="Intitulé ">
            </div>
        </div>
        </div>

        <div class="row justify-content-around">
       
        <div class="col-6">
            <div class="form-group">
                <strong>Montant : <span class="text-danger">*</span></strong>
                <input type="decimal" class="form-control" name="montantsou_traitance" placeholder="Montant ">
            </div>
        </div>
        
        <div class="col-6">
            <div class="form-group">
                <strong>Date : <span class="text-danger">*</span></strong>
                <input type="date" class="form-control" name="datesou_traitance" placeholder="Date ">
            </div>
        </div>
        </div>

        <div class=" text-right">
                <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-plus-circle"> </i> Ajouter</button>
                <button type="reset" class="btn btn-info" style="margin-left: 10px;"><i class="fa fa-fw fa-sync" ></i> Réinitialiser</button>
        </div>
    </div>
   
</form>
    </div>
            </div>
    </div>
!-->
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('soutraitances.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/soutraitances/create.blade.php ENDPATH**/ ?>