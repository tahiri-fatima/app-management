
 
<?php $__env->startSection('content'); ?>


<!-- Alert si le code est dupliqué !-->
<?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> N'éxiste aucun frais avec les informations de la recherche !<br><br>
        </div>
<?php endif; ?>

<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('frais.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 


<div class="col  justify-content-center">    

<div class="blog-header py-1">
				<h3>Résultat de la recherche </h3>
</div>
		<div>
     
			<table class="table table-striped table-bordered text-center">
            <thead>
					<tr class="bg-primary text-white">
                    <th >Code du frais</th>
						<th >Nature du frais</th>
                        <th >Date du frais</th>
						<th >Montant du frais</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
                <?php $__currentLoopData = $frais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($frai->code_frais); ?></td>
            <td><?php echo e($frai->nature); ?></td>
            <td><?php echo e($frai->date_frais); ?></td>
            <td><?php echo e($frai->montant_frais); ?></td>
            <td>
                <form action="<?php echo e(route('frais.destroy',$frai->id)); ?>" method="POST"  >
   
                    <a class="btn btn-info" href="<?php echo e(route('frais.show',$frai->id)); ?>" style="margin-left: 15px;"><i class="fa fa-fw fa-eye"></i>Consulter</a>
    
                    <a class="btn btn-primary"  href="<?php echo e(route('frais.edit',$frai->id)); ?>" style="margin-left: 15px;"><i class="fa fa-fw fa-edit"></i>Editer</a>

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger" style="margin-left: 15px;" ><i class="fa fa-fw fa-trash"></i> Supprimer</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div> <!--/.col-sm-12-->
		

</div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frais.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/frais/search.blade.php ENDPATH**/ ?>