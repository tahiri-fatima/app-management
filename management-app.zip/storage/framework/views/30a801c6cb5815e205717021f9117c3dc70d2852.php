
 
<?php $__env->startSection('content'); ?>

<div class="container" style=" width: 200%; ">
		<div class="card">
			<div class="card-body">
				
				<div >
					<h5 class="card-title"><i class="fa fa-fw fa-search"></i> Chercher réparation</h5>

                        <form class="form-inline " type="get" action="<?php echo e(route('ordreServices.search')); ?>" >
                                <div class="row" >
                                <div class="form-group" style="margin-right: 15px;" >
                                    <input class="form-control mr-ms-2" name="codeordreserv"  type="search" placeholder="Code ordre" >
                                </div>
                                <div class="form-group" style="margin-right: 15px;" >
                                    <input class="form-control mr-ms-2" name="typeordreserv"  type="search" placeholder="Type d'ordre" >
                                </div>

                                <div class="form-group " style="margin-right: 15px;" >
                                    <button class="btn btn-primary" type="submit" value="search" style="margin-right: 15px;" ><i class="fa fa-fw fa-search"></i> Chercher</button>
                                    <button type="reset" class="btn btn-info" > <i class="fa fa-fw fa-sync"></i> Réinitialiser</button>
                                </div>
                                </div>
                        </form>
                </div>
            </div>
        </div>
       </div>

<div  >
		<div class="container" style="margin-top: 20px;">
			
        <div class="text-right"> 
            <a class="btn btn-primary text-right" href="<?php echo e(route('ordreServices.create')); ?>"><i class="fa fa-fw fa-plus-circle"></i> Ajouter nouvelle réparation</a> 
            <a class="btn btn-primary text-right" href="/" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
        </div> 

		</div> <!--/.container-->
</div>
	



      
     

		<div>
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        
				<h3>Liste des ordres</h3>
			
			<table class="table table-striped table-bordered">
				<thead>
					<tr class="bg-primary text-white">
						<th class="text-center">Code</th>
						<th class="text-center">Type</th>
                        <th class="text-center">Date</th>
						<th class="text-center">Action</th>
					</tr>
				</thead>
				<tbody>
                <?php $__currentLoopData = $ordreServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordreService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($ordreService->codeordreserv); ?></td>
            <td><?php echo e($ordreService->typeordreserv); ?></td>
            <td><?php echo e($ordreService->dateordreserv); ?></td>
            <td>
                <form action="<?php echo e(route('ordreServices.destroy',$ordreService->codeordreserv)); ?>" method="POST" class="text-center" >
   
                    <a class="btn btn-info" href="<?php echo e(route('ordreServices.show',$ordreService->codeordreserv)); ?>" style="margin-left: 15px;"><i class="fa fa-fw fa-eye"></i>Consulter</a>
    
                    <a class="btn btn-primary"  href="<?php echo e(route('ordreServices.edit',$ordreService->codeordreserv)); ?>" style="margin-left: 15px;"><i class="fa fa-fw fa-edit"></i>Editer</a>

   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger" style="margin-left: 15px;" ><i class="fa fa-fw fa-trash"></i> Supprimer</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div> <!--/.col-sm-12-->
		

   
<div class="text-right">
    <?php echo $ordreServices->links(); ?>


    </div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ordreServices.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/ordreServices/index.blade.php ENDPATH**/ ?>