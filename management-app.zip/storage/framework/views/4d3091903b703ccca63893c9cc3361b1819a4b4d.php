
   
<?php $__env->startSection('content'); ?>
  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('entretiens.show',$entretien->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 
   
<div class="col  justify-content-center" > 

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un entretien avec ce code d'entretien.<br><br>
            
        </div>
    <?php endif; ?>
</div>


<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:70%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-edit"></i>  Modifier l'entretien</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

<form class="form-material" action="<?php echo e(route('entretiens.update',$entretien->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>
            <div class="row justify-content-around" >
                 <div class="col-6">
                <div class="form-group form-primary form-static-label">
                <label ><strong> Code d'entretien </strong><span class="text-danger">*</span> </label>
                    <input type="text" name="code_entretien" value="<?php echo e($entretien->code_entretien); ?>" class="form-control" placeholder="Entrer le code d'entretien">
                    <span class="form-bar"></span>

                </div>
                 </div>

              <div class="col-6">           
                  <div class="form-group form-primary form-static-label">
                  <label ><strong> Inttulé d'entretien </strong><span class="text-danger">*</span> </label>
                    <input type="text" name="intitule_entretien" value="<?php echo e($entretien->intitule_entretien); ?>" class="form-control" placeholder="Entrer l'intitulé' d'entretien">
                    <span class="form-bar"></span>
                 </div>   
                </div>
            </div>
            <div class="row justify-content-around" >
        <div class="col-6">
                <div class="form-group form-primary form-static-label">
                <label ><strong> Montant d'entretien </strong><span class="text-danger">*</span> </label>
                    <input type="double" name="montant_entretien" value="<?php echo e($entretien->montant_entretien); ?>" class="form-control" placeholder="Entrer le montant d'entretien">
                    <span class="form-bar"></span>
               </div>
        </div>
        <div class="col-6">
                <div class="form-group form-primary form-static-label">
                <label ><strong> Date d'entretien </strong><span class="text-danger">*</span> </label>
                    <input type="date" name="date_entretien" value="<?php echo e($entretien->date_entretien); ?>" class="form-control" placeholder="Entrer la date d'entretien">
                    <span class="form-bar"></span>
                     </div>
        </div>
            </div>

            <div class="row">
                <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                        <label ><strong>Matériel </strong><span class="text-danger">*</span> </label>
                            <div class="select">
                            <select class="form-control" name="materiel_id">
                                <option value="<?php echo e($materiel->id); ?>"><?php echo e($materiel->intitule_materiel); ?></option>
                                <?php $__currentLoopData = $materiels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materiel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($materiel->id); ?>"><?php echo e($materiel->intitule_materiel); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>               
                            <span class="form-bar"></span>
                            
                        </div>
                </div>
                </div>
            </div>
                <div class=" text-right">
                        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
                </div>
                                                 
            </form>
         </div>
    </div>
<!-- end formulaire -->

    <!-- formulaire 
    <div class="card">

<div class="card-header"><strong> Modifier la entretien</strong> </div>

    <div class="card-body">
        
        <div class="col-sm-8">

<form action="<?php echo e(route('entretiens.update',$entretien->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>

    <div class="row justify-content-around">
        <div class="col-6">
            <div class="form-group">
            <label > <strong>Code : <span class="text-danger">*</span></strong></label>
                <input type="text" name="codeentretien" value="<?php echo e($entretien->codeentretien); ?>" class="form-control" placeholder="Code">
            </div>
        </div>

        <div class="col-6">
                <div class="form-group">
                <label>  <strong>Intitulé : <span class="text-danger">*</span></strong></label>
                    <input type="text" class="form-control" name="intituleentretien" value="<?php echo e($entretien->intituleentretien); ?>" placeholder="Intitulé entretien">
                </div>
        </div>
    </div>

    <div class="row justify-content-around">
        <div class="col-6">
            <div class="form-group">
            <label > <strong>Montant d'entretien : <span class="text-danger">*</span></strong></label>
                <input type="decimal" class="form-control" name="montantentretien" value="<?php echo e($entretien->montantentretien); ?>" placeholder="Montant entretien">
            </div>
        </div>
        
        <div class="col-6">
            <div class="form-group">
            <label ><strong>Date d'entretien : <span class="text-danger">*</span></strong></label>
                <input type="date" class="form-control" name="dateentretien" value="<?php echo e($entretien->dateentretien); ?>" placeholder="Date entretien">
            </div>
        </div>
    </div>

    <div class="row ">
        <div class="col-6">
                <div class="form-group">
                    <label ><strong>Matériel : <span class="text-danger">*</span></strong></label>
                    <div class="select">
                    <select class="form-control" name="materiel_id" >
                        <option value="<?php echo e($materiel->id); ?>"><?php echo e($materiel->intitulemateriel); ?></option>
                        <?php $__currentLoopData = $materiels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materiel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($materiel->id); ?>"><?php echo e($materiel->intitulemateriel); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>
                </div>
        </div>
    </div>

<div class=" text-right">
        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
</div>
</div>

</form>
</div>
    </div>
</div>
!-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('entretiens.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/entretiens/edit.blade.php ENDPATH**/ ?>