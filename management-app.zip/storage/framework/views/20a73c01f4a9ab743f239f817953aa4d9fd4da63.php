
 
<?php $__env->startSection('content'); ?>


<div class="container  " style="margin-left: 190px;" >
		<div class="card">
			<div class="card-body">
				
				<div >
					<h5 class="card-title"><i class="fa fa-fw fa-search"></i> Chercher chantier</h5>

                        <form class="form-material" type="get" action="<?php echo e(route('chantiers.search')); ?>" >
                            <div class="row justify-content-around">
                                <div class="col-4">
                                    <div class="form-group">
                                        <input class="form-control mr-ms-2" name="codechantier"  type="search" placeholder="Code du chantier " >
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <input class="form-control mr-ms-2" name="intitulechantier"  type="search" placeholder="Intitulé du chantier " >
                                    </div>
                                </div>
                                <div class="row pull-right" style="margin-right: 15px;">
                                    <div class="form-group " >
                                        <button class="btn btn-primary" type="submit" value="search"  ><i class="fa fa-fw fa-search"></i> Chercher</button>
                                        <button type="reset" class="btn btn-info" > <i class="fa fa-fw fa-sync"></i> Réinitialiser</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                </div>
            </div>
        </div>
       </div>


       
<div class="form-material" style="margin-top: 20px;margin-bottom: 20px;margin-left: 50px;">
	


        <div class="col  justify-content-center message">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <?php if($message = Session::get('warning')): ?>
        <div class="alert alert-info">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        </div>
        <div class="col  justify-content-center ">
        
        <form  class="form-material" action="<?php echo e(route('chantiers.getBilan')); ?>" method="get">
            
        <div  style="margin-left: 150px;" >
        <div class="row ">
        <h6  >Sélectionner un chantier  </h6>

        </div>

            <div class="col-6">
                <div class="form-group form-primary form-static-label">
                    <select class="form-control" id="chantiers" type="dropdown-toggle" name="chantier_id" >
                        <option value="" selected disabled>Choisir chantier</option>
                        <?php $__currentLoopData = $chantiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chantier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="chantiers" value="<?php echo e($chantier->id); ?>"><?php echo e($chantier->intitule_chantier); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>                
                <span class="form-bar"></span>
                     
            </div>
        </div>

        <div class=" text-right" style="margin-top: 10px;margin-right: 150px;">
                <button  class="btn btn-primary" type="submit" name="tableau"  > Tableau</button>
                <button  class="btn btn-info" type="submit" style="margin-left: 10px;" name="graphes"> Graphes</button>
        </div>
</form>
        
      

</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/edition/ListChantierBilan.blade.php ENDPATH**/ ?>