
   
<?php $__env->startSection('content'); ?>


  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('chantiers.show',$chantier->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 
   <div class="col d-flex justify-content-center">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un chantier avec ce code de chantier.<br><br>
            
        </div>
    <?php endif; ?>

<!-- Alert si la date fin est supérieure à la date début !-->
<?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 2): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il faut entrer une date fin supérieure à la date début de chantier !<br><br>
            
        </div>
<?php endif; ?>
   </div>

<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:70%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-edit"></i>  Modifier le chantier</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold; margin-bottom: 30px;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

            <form class="form-material" action="<?php echo e(route('chantiers.update',$chantier->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
                
                <div class="row justify-content-around" >
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                        <label class="float-label" style="top: -14px; font-size: 11px; color: #448aff;">Code du chantier <span class="text-danger">*</span> </label>
                            <input type="text" name="code_chantier" value="<?php echo e($chantier->code_chantier); ?>" class="form-control" placeholder="Entrer le code du chantier">
                            <span class="form-bar"></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                        <label class="float-label" style="top: -14px; font-size: 11px; color: #448aff;">Intitulé du chantier<span class="text-danger">*</span> </label>
                            <input type="text" name="intitule_chantier" value="<?php echo e($chantier->intitule_chantier); ?>" class="form-control" placeholder="Entrer l'intitulé du chantier">
                            <span class="form-bar"></span>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-around" >
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                        <label class="float-label" style="top: -14px; font-size: 11px; color: #448aff;">Réfèrence de soumission <span class="text-danger">*</span> </label>
                            <input type="text" name="ref_soumission" value="<?php echo e($chantier->ref_soumission); ?>" class="form-control" placeholder="Entrer le réfèrence">
                            <span class="form-bar"></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                        <label class="float-label" style="top: -14px; font-size: 11px; color: #448aff;">Localisation <span class="text-danger">*</span> </label>
                            <input type="text" name="localisation" value="<?php echo e($chantier->localisation); ?>" class="form-control" placeholder="Entrer localisation">
                            <span class="form-bar"></span>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-around" >
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                        <label class="float-label" style="top: -14px; font-size: 11px; color: #448aff;">Date début du chantier <span class="text-danger">*</span> </label>
                            <input type="date" name="date_debut_chantier" value="<?php echo e($chantier->date_debut_chantier); ?>" class="form-control" placeholder="Entrer la date début du chantier">
                            <span class="form-bar"></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                        <label class="float-label" style="top: -14px; font-size: 11px; color: #448aff;">Date fin du chantier  </label>
                            <input type="date" name="date_fin_chantier" value="<?php echo e($chantier->date_fin_chantier); ?>" class="form-control" placeholder="Entrer la date fin du chantier">
                            <span class="form-bar"></span>
                        </div>
                    </div>
                </div>


                <div class=" text-right">
        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
</div>
                                                 
            </form>
         </div>
    </div>

<!-- end Formulaire -->

  <!-- formulaire 
    <div class="col justify-content-around" >

  
    <div class="card">

<div class="card-header"><strong> Modifier le chantier</strong> </div>

    <div class="card-body">
        
        <div class="col-sm-8">

<form action="<?php echo e(route('chantiers.update',$chantier->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>

   <div class="row justify-content-around" >
        <div class="col-6">
            <div class="form-group">
                <strong>Code : <span class="text-danger">*</span></strong>
                <input type="text" name="codechantier" value="<?php echo e($chantier->codechantier); ?>" class="form-control" placeholder="Code">
            </div>
        </div>
        
        <div class="col-6">
            <div class="form-group">
                <strong>Intitulé : <span class="text-danger">*</span></strong>
                <input type="text" class="form-control" value="<?php echo e($chantier->intitulechantier); ?>" name="intitulechantier" placeholder="Intitulé">
            </div>
        </div>
    </div>

    <div class="row justify-content-around">
        <div class="col-6">
            <div class="form-group">
                <strong>Réfèrence de soumission : <span class="text-danger">*</span></strong>
                <input type="text" name="refsoumission" class="form-control" value="<?php echo e($chantier->refsoumission); ?>" placeholder="Réfèrence de soumission">
            </div>
        </div>

        <div class="col-6">
            <div class="form-group">
                <strong>Localisation : <span class="text-danger">*</span></strong>
                <input type="text" class="form-control" name="localisation" value="<?php echo e($chantier->localisation); ?>" placeholder="Localisation">
            </div>
        </div>
    </div>

    <div class="row justify-content-around">
        <div class="col-6">
            <div class="form-group">
                <strong>Date début du chantier : <span class="text-danger">*</span></strong>
                <input type="date" class="form-control" name="datedebutchantier" value="<?php echo e($chantier->datedebutchantier); ?>" placeholder="Date début du chantier">
            </div>
        </div>

        <div class="col-6">
            <div class="form-group">
                <strong>Date fin du chantier : <span class="text-danger">*</span></strong>
                <input type="date" class="form-control" name="datefinchantier" value="<?php echo e($chantier->datefinchantier); ?>" placeholder="Date fin du chantier">
            </div>
        </div>
    </div>

    


<div class=" text-right">
        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
</div>
</div>

</form>
</div>
    </div>
</div>
!-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('chantiers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/chantiers/edit.blade.php ENDPATH**/ ?>