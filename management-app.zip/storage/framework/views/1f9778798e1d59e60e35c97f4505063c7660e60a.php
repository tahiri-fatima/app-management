
  
  <?php $__env->startSection('content'); ?>
    
  <div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
      <a class="btn btn-primary" href="<?php echo e(route('fournisseurs.listeCommandesFournisseur')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
      <button class="btn btn-primary" type="button" onclick="PrintPage()" value="Imprimer" ><i class="fa fa-print" aria-hidden="true"></i>Imprimer</button>
  </div> 
  
  
  
  <div class="col d-flex justify-content-center" id="printableArea"> 
  
  <div style="width:80%" >
      <div class="card ">
  
      <div>
                      <h5 style="margin:20px 15px 20px 15px;">Liste des commandes du fournisseur <?php echo e($fournisseur->intitule_fournisseur); ?> </h5>
                      <table class="table m-b-0 text-center">
                          <thead style="font-weight:bold">
                              <td>Code commande</td>
                              <td>Date de la commande</td>
                              <td>Montant de la commande</td>
                              <td>Cumul acompte</td>
                          </thead>
                          <tbody >
  
                          <?php $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td ><?php echo e($commande->code_commande); ?> </td>
                                  <td ><?php echo e($commande->date_commande); ?> </td>
                                  <td ><?php echo e($commande->total_commande); ?></td>
                                    <td ><?php echo e($commande->cumul_acompte); ?> </td>
                              </tr>
  
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                              <tr>
                                  <td colspan="2"  >Total</td>
                                  <td ><?php echo e($fournisseur->total_montant_commandes); ?></td>
                                  <td ><?php echo e($fournisseur->total_cumul_acompte); ?></td>
                              </tr>
                              <tr>
                                  <td colspan="2" >Montant Net</td>
                                  <td colspan="2" ><?php echo e($fournisseur->montant_net); ?></td>
                              </tr>
                          </tbody>
                      </table>   
  
                   </div>  
  
           
      </div>
  </div>
  
  
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/fournisseurs/getCommandes.blade.php ENDPATH**/ ?>