

  
  <?php $__env->startSection('content'); ?>
    
  <div class=" text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
      <a class="btn btn-primary" href="<?php echo e(route('chantiers.listeFraisChantier')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
      <button class="btn btn-primary" type="button" onclick="PrintPage()" value="Imprimer" ><i class="fa fa-print" aria-hidden="true"></i>Imprimer</button>
  </div> 
  
  
  
  <div class="col d-flex justify-content-center" id="printableArea"> 
  
  <div style="width:90%" >
      <div class="card ">
  
      <div>
      <div class="text-center">
           <img class="img" src="<?php echo e(url('assets/images/logo.png')); ?>"  style="width: 170px; height: 70px; margin-top:25px " />
           <h5 style="margin:30px 15px 30px 15px; text-align:center">Liste des frais </h5>

                      
            </div>
                      <table class="table m-b-0 text-center" >
                          <thead style="font-weight:bold">
                              <td>Code Frais</td>
                              <td>Catégorie</td>
                              <td>Cible</td>
                              <td>Montant</td>
                          </thead>
                          <tbody >
  <?php $total=0 ?>
                          <?php $__currentLoopData = $frais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr >
                                  <td ><?php echo e($frai->code_frais); ?> </td>
                                  <td ><?php echo e($frai->nature_frais); ?> </td>
                                  <td> <?php echo e($frai->cible_frais); ?></td>
                                  <td ><?php echo e($frai->montant_frais); ?> </td>
                              </tr>
                              <?php $total += $frai->montant_frais ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <tr >
                                  <td colspan="3" style="font-weight:bold" >Total </td>
                                  <td > <?php echo e($total); ?> </td>
                              </tr>
                            
                          </tbody>
                      </table>   
  
                   </div>  
  
           
      </div>
  </div>
  
  
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/chantiers/listeFrais.blade.php ENDPATH**/ ?>