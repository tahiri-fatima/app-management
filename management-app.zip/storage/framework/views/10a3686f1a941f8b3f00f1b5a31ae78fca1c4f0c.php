


  
<?php $__env->startSection('content'); ?>

<div class="container " style="margin-left: 70%;" > 
            <a class="btn btn-primary" href="<?php echo e(route('roles.show', $role->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col d-flex justify-content-center" > 


<?php if($errors->any()): ?>
    <div class="alert alert-danger message">
        <strong>Whoops!</strong> Il y'a un problème avec les information que vous avez entrées.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger message">
         <p>   <strong>Whoops!</strong> Il y a dejà un rôle avec ce code.<br><br> </p>
            
        </div>
    <?php endif; ?>



</div>




<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:80%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-plus-circle"></i>  Modifier le rôle <?php echo e($role->name); ?></h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold; margin-bottom : 30px;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

            
        <form class="form-material" action="<?php echo e(route('roles.update',$role->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>

            <div class="row justify-content-around">
               
                 <div class="col-6">
                    <div class="form-group form-primary form-static-label">
                        <input type="text" name="name" value="<?php echo e($role->name); ?>" class="form-control" placeholder="Entrer le nom du role">
                        <span class="form-bar"></span>
                        <label class="float-label">Nom du rôle<span class="text-danger">*</span> </label>
                    </div>
                 </div>
            </div>

           
                <div class="row justify-content-around">
                <div class="col-6">
                <div class="multi-select form-group form-primary form-static-label" >
                        <label  >Permissions <span class="text-danger">*</span> </label>
                        <div class="select" >
                            <select id="mySelect" class="select2-multiple" name="permissions[]" multiple size="5" style="width: 100%;" >
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(in_array($permission->id , $rolePermissions)): ?>
                                        <option value="<?php echo e($permission->id); ?>" selected="true"> <?php echo e($permission->name); ?>  </option>
                                <?php else: ?>
                                    <option  value="<?php echo e($permission->id); ?>" >   
                                        <?php echo e($permission->name); ?>

                                    </option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>                                                                   
                    </div>
                </div>

                   

                     
                </div>


                <div class=" text-right" style="margin-top: 10px;">
                <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Modifier</button>
                 </div>
                                                 
            </form>
         </div>
    </div>

<!-- end Formulaire -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('roles.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/roles/edit.blade.php ENDPATH**/ ?>