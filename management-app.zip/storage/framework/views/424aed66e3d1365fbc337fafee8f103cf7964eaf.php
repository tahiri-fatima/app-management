
   
<?php $__env->startSection('content'); ?>


  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('commandeMateriaus.showMateriaux',$commande->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col d-flex justify-content-center" > 
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un enregistrement avec ce code ce couple de code commande et matériau.<br><br>
            
        </div>
    <?php endif; ?>

</div>


<!-- start Formulaire -->

<div class="col d-flex justify-content-center" >

    <div class="card" style="width:90%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-plus-circle"></i>  Modifier les matériaux</h5>
        </div>
        <div class="card-block">
            <form class="form-material" action="<?php echo e(route('commandeMateriaus.updateMateriaux',$commande->id)); ?>"  enctype="multipart/form-data" onsubmit="return verifierChampsCommande()" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row justify-content-around" style="margin-bottom: 20px; ">
                <div class="col-6">
                    <div class="form-group form-primary form-static-label">
                    <label class="form-label " style="top: -14px; font-size: 11px; color: #448aff;">Commande <span class="text-danger">*</span> </label>
                        <div class="select">
                            <select class="form-control" name="commande_id" >
                            <option value="<?php echo e($commande->id); ?>"><?php echo e($commande->code_commande); ?></option>
                                <?php $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($commande->id); ?>"><?php echo e($commande->code_commande); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>                
                        <span class="form-bar"></span>   
                    </div>
                </div>

                <div class="col-6">
                    <div class="multi-select" >
                        <label  style="top: -14px; color: black;">Matériaux <span class="text-danger">*</span> </label>
                        <div class="select" >
                            <select id="mySelect" class="materiaux" name="materiaus[]" multiple size="5" style="width: 100%;" >
                                <?php $__currentLoopData = $materiaus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materiau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <?php if(in_array($materiau->id , $materiaux)): ?>
                                            <option value="<?php echo e($materiau->id); ?>" selected="true"><?php echo e($materiau->intitule_materiau); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($materiau->id); ?>"> <?php echo e($materiau->intitule_materiau); ?>  </option>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                            </select>
                        </div>                                                                   
                    </div>
                </div>
            </div>
   

              
                
                    <h5>Liste des matériaux commandés :</h5>
                    <table class="table m-b-0 text-center">
                        <thead>
                            <td>Matériau</td>
                            <td>Code matériau</td>
                            <td>Prix Unitaire</td>
                            <td>Quantité</td>
                            <td>Montant</td>
                        </thead>
                        <tbody >
<?php $k=1; ?>
                            <?php $__currentLoopData = $materiaus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materiau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="display:none;" id="<?php echo e($materiau->id); ?>" class="data">
                                    <td > <?php echo e($materiau->intitule_materiau); ?> </td>
                                    <td> <input type="text" class="text-center"  name="code_materiau[]" value="<?php echo e($materiau->code_materiau); ?>" style="border:none;" readonly> </td>
                                    <td> <input type="text" class="text-center" id="prix<?php echo e($materiau->id); ?>"  name="prix_unit_materiau" value="<?php echo e($materiau->prix_unit_materiau); ?>" style="border:none;" readonly> </td>
                                    <td>
                                    <?php if(in_array($materiau->id , $materiaux)): ?>
                                        <input type="number" class="quantite text-center" id="q<?php echo e($materiau->id); ?>" name="quantite_materiau[]"  style="border:none;" 
                                        placeholder="Entrer la quantité" onchange="recupValeur(this.value, this.id);"  
                                        value= "<?php echo e($materiaux[$k]); ?>" >
                                        <?php $k+=2; ?>
                                    <?php else: ?>
                                        <input type="number" class="quantite text-center" id="q<?php echo e($materiau->id); ?>" name="quantite_materiau[]"  style="border:none;" 
                                        placeholder="Entrer la quantité" onchange="recupValeur(this.value, this.id);"  
                                        value= "" >
                                     <?php endif; ?>                                    
                                    </td>
                                    <td ><input type="decimal" class="montant text-center" id="montant<?php echo e($materiau->id); ?>" name="montant_materiau[]" value="0" style="border:none;" readonly></td>
                                </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr class="text-center">
                                    <td colspan="4"  >Total</td>
                                    <td ><input type="decimal" class="text-center" name="total_commande" value="0" style="border:none;" id="total" readonly></td>
                                </tr>
                        </tbody>
                    </table>
                   
                <div class=" text-right" style="margin-top: 10px;">
                    <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-plus-circle" > </i> Modifier</button>
                    <button type="reset" class="btn btn-info" style="margin-left: 10px;"><i class="fa fa-fw fa-sync" ></i> Réinitialiser</button>
                </div>
                                                 
            </form>

         </div>
    </div>    
</div>

<!-- end Formulaire -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('commandeMateriaus.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/commandeMateriaus/edit.blade.php ENDPATH**/ ?>