
  
<?php $__env->startSection('content'); ?>

<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 70px; "> 
    <form action="<?php echo e(route('chantiers.destroy',$chantier->id)); ?>" method="POST" > 
        <a class="btn btn-outline-primary text-right" href="<?php echo e(route('chantiers.create')); ?>"><i class="fa fa-fw fa-plus-circle"></i> Ajouter nouveau chantier</a> 

        <a class="btn btn-outline-primary"  href="<?php echo e(route('chantiers.edit',$chantier->id)); ?>" ><i class="fa fa-fw fa-edit"></i> Modifier</a>

        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <button type="submit" class="btn btn-outline-primary"  ><i class="fa fa-fw fa-trash"></i> Supprimer</button>
        <a class="btn btn-outline-primary" href="<?php echo e(route('chantiers.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 

    </form>
</div> 



<div class="col d-flex justify-content-center"> 

<div class="col-xl-6 col-md-12 ">
    <div class="card table-card">

         <div class="card-header">
            <h5>Détails du chantier</h5>
                <div class="card-header-right">
                    <ul class="list-unstyled card-option">
                        <li><i class="fa fa fa-wrench open-card-option"></i></li>
                        <li><i class="fa fa-window-maximize full-card"></i></li>
                        <li><i class="fa fa-minus minimize-card"></i></li>
                     </ul>
                </div>
            </div>
            
            <div class="card-block">
                <div class="table-responsive">
                    <table class="table table-hover m-b-0 without-header">
                        <tbody>
                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Code du chantier : </h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($chantier->code_chantier); ?> </h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Intitule du chantier : </h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($chantier->intitule_chantier); ?> </h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Réfèrence de soumission : </h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($chantier->ref_soumission); ?> </h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Localisation : </h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($chantier->localisation); ?> </h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>  

                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Date début du chantier : </h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($chantier->date_debut_chantier); ?> </h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Date début du chantier : </h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($chantier->date_fin_chantier); ?> </h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                            
                        </tbody>
                    </table>
                 </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('chantiers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/chantiers/show.blade.php ENDPATH**/ ?>