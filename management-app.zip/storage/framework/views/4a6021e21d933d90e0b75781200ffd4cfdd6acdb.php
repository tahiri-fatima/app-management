
   
<?php $__env->startSection('content'); ?>
  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('executions.show',$execution->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 
   
<div class="col  justify-content-center" > 

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
<!-- Alert si le code est dupliqué !-->
<?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 1): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un exécution avec ce code d'exécution.<br><br>
            
        </div>
    <?php endif; ?>
</div>


<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:50%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-edit"></i> Modifier l'exécution</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold; ">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

        <form class="form-material" action="<?php echo e(route('executions.update',$execution->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
           
                <div class="form-group form-primary form-static-label">
                <label ><strong>Numéro d'exécution d'ouvrage </strong> <span class="text-danger">*</span></label>
                    <input type="number" name="num_execution_ouvrage" value="<?php echo e($execution->num_execution_ouvrage); ?>"  class="form-control" placeholder="Entrer le numéro d'execution d'ouvrage">
                    <span class="form-bar"></span>
                   </div>
                          
                  <div class="form-group form-primary form-static-label">
                  <label ><strong>Date d'exécution </strong> <span class="text-danger">*</span></label>
                    <input type="date" name="date_execution" value="<?php echo e($execution->date_execution); ?>" class="form-control" >
                    <span class="form-bar"></span>
                   </div>   
                
                <div class="form-group form-primary form-static-label">
                <label ><strong>Quantité realisée </strong> <span class="text-danger">*</span></label>
                    <input type="number" name="quantite_realisee" value="<?php echo e($execution->quantite_realisee); ?>" class="form-control" placeholder="Entrer la quantité réalisée">
                    <span class="form-bar"></span>

                     </div>
        
                <div class="form-group form-primary form-static-label">
                <label ><strong>Désignation d'opération </strong> <span class="text-danger">*</span></label>
                <div class="select">
                    <select class="form-control" name="operation_id">
                    <option value="<?php echo e($operation->id); ?>"><?php echo e($operation->designation_operation); ?></option>
                        <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($operation->id); ?>"><?php echo e($operation->designation_operation); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>               
                     <span class="form-bar"></span>
                     
                </div>
        </div>
        
                
        <div class=" text-right">
                <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
        </div>
                                                 
            </form>
         </div>
    </div>
<!-- end formulaire -->

    <!-- formulaire 
    <div class="card">

<div class="card-header"><strong> Modifier l'execution</strong> </div>

    <div class="card-body">
        
        <div class="col-sm-8">

<form action="<?php echo e(route('executions.update',$execution->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>

<div class="row justify-content-around">
    <div class="col-6">
        <div class="form-group">
        <label > <strong>Numéro : <span class="text-danger">*</span></strong></label>
            <input type="text" class="form-control" name="numexecutionouvrage" value="<?php echo e($execution->numexecutionouvrage); ?>" class="form-control" placeholder="Numéro">
        </div>
    </div>

    <div class="col-6">
        <div class="form-group">
        <label ><strong>Date d'execution : <span class="text-danger">*</span></strong></label>
            <input type="text" class="form-control" value="<?php echo e($execution->dateexecution); ?>" name="dateexecution" placeholder="Date d'execution">
        </div>
    </div>
</div>

<div class="row justify-content-around">
    <div class="col-6">
        <div class="form-group">
        <label><strong>Quantité réalisée : <span class="text-danger">*</span></strong></label>
            <input type="double" name="quantiterealisee" class="form-control" value="<?php echo e($execution->quantiterealisee); ?>" placeholder="Quantité réalisée">
        </div>
    </div>

    <div class="col-6">
                <div class="form-group">
                    <label ><strong>Désignation d'opération : <span class="text-danger">*</span></strong></label>
                    <div class="select">
                    <select class="form-control" name="operation_id" >
                        <option value="<?php echo e($operation->id); ?>"><?php echo e($operation->designationoperation); ?></option>
                        <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($operation->id); ?>"><?php echo e($operation->designationoperation); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>
                </div>
        </div>
</div>



<div class=" text-right">
        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
</div>
</div>

</form>
</div>
    </div>
</div>
!-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('executions.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/executions/edit.blade.php ENDPATH**/ ?>