


  
<?php $__env->startSection('content'); ?>

  
<div class="container " style="margin-left: 70%;" > 
            <a class="btn btn-primary" href="<?php echo e(route('commandes.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 


<?php if($errors->any()): ?>
    <div class="alert alert-danger message">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger message">
        <p>    <strong>Whoops!</strong> Il y a dejà une commade avec ce code.<br><br> </p>
            
        </div>
    <?php endif; ?>

<!-- Affichage de modal si l'enregistrement ajouté avec succes. !-->
    <?php if(!empty(Session::get('success')) && Session::get('success') == 'Enregistrement ajouté avec succes.'): ?>
    <script>
        $(function() {
            $('#myModal').modal('show');
        });
    </script>
    <?php endif; ?>

<!-- modal si commande ajouté avec succes !-->
<div class="modal" tabindex="-1" role="dialog" id="myModal" >
  <div class="modal-dialog" role="document" >
    <div class="modal-content">
      <div class="modal-header" >
        <h5 class="modal-title" style="color:#228B22;" > Ajout avec succes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
          <strong >
            <p>Commande ajouté avec succes.</p>
            <p>Voulez vous insérer une autre commande ?</p>
        </strong>
      </div>
      <div class="modal-footer">
        <a class="btn btn-outline-secondary" href="<?php echo e(route('commandes.index')); ?>"> Non</a>
        
        <button type="button" class="btn btn-outline-success" data-dismiss="modal">Oui</button>
      </div>
    </div>
  </div>
</div>

<!-- modal de la confirmation !-->
<div class="modal" tabindex="-1" role="dialog" id="modal2" >
  <div class="modal-dialog" role="document" >
    <div class="modal-content" >
    
    <div class="modal-header" >
        <h5 class="modal-title" style="color:#228B22;" > Confirmation d'ajout</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
          <strong >
            
            <p>Pouvez vous confirmer l'ajout de ce nouveau enregistrement ? </p>
        </strong>
      </div>
      <div class="modal-footer">
        <a type="submit" class="btn btn-outline-success confirmer" > Confirmer</a>
        
        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal"> Annuler</button>
      </div>
    </div>
    </div>
  </div>

<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:70%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-plus-circle"></i>  Ajouter nouvelle commande</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold; margin-bottom : 30px;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

            <form id="form" class="form-material" action="<?php echo e(route('commandes.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
                
                <div class="row justify-content-around" >
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <input type="text" name="code_commande" class="form-control" placeholder="Entrer le code de la commande">
                            <span class="form-bar"></span>
                            <label class="float-label">Code de la commande <span class="text-danger">*</span> </label>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <input type="date" name="date_commande" class="form-control" placeholder="Entrer la date de la commande">
                            <span class="form-bar"></span>
                            <label class="float-label">Date de la commande <span class="text-danger">*</span> </label>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-around" >
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <label class="select-label " >Fournisseurs <span class="text-danger">*</span> </label>
                            <div class="select">
                                <select class="form-control" name="fournisseur_id">
                                    <option value="">Selectionner fournisseur</option>
                                    <?php $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($fournisseur->id); ?>"><?php echo e($fournisseur->intitule_fournisseur); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <span class="form-bar"></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <label class="select-label " >Chantier <span class="text-danger">*</span> </label>
                            <div class="select">
                                <select class="form-control" name="chantier_id">
                                    <option value="">Selectionner Chantier</option>
                                    <?php $__currentLoopData = $chantiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chantier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($chantier->id); ?>"><?php echo e($chantier->intitule_chantier); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                            <span class="form-bar"></span>
                        </div>
                    </div>
                    
                </div>             
                
                

                <div class=" text-right" style="margin-top: 10px;">
                    <button type="button" class="btn btn-primary" onclick="$('#modal2').modal('show');"> <i class="fa fa-fw fa-plus-circle"> </i> Ajouter </button>
                    <button type="reset" class="btn btn-info" style="margin-left: 10px;"><i class="fa fa-fw fa-sync" ></i> Réinitialiser</button>
                </div>
                                                 
            </form>
         </div>
    </div>

<!-- end Formulaire -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('commandes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/commandes/create.blade.php ENDPATH**/ ?>