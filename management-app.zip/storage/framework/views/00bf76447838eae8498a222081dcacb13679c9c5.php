

<?php $__env->startSection('content'); ?>
  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('fournisseurs.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col d-flex justify-content-center" > 

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 1): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un fournisseur avec ce code de fournisseur.<br><br>
            
        </div>
    <?php endif; ?>

<!-- Affichage de modal si la reparation ajouté avec succes. !-->
    <?php if(!empty(Session::get('success')) && Session::get('success') == 'fournisseur ajouté avec succes.'): ?>
    <script>
        $(function() {
            $('#myModal').modal('show');
        });
    </script>
    <?php endif; ?>

<!-- modal si reparation ajouté avec succes !-->
<div class="modal" tabindex="-1" role="dialog" id="myModal" >
  <div class="modal-dialog" role="document" >
    <div class="modal-content">
      <div class="modal-header" >
        <h5 class="modal-title" style="color:#228B22;" > Ajout avec succes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
          <strong >
            <p>Enregistrement ajoutée avec succes.</p>
            <p>Voulez vous insérer une autre enregistrement ?</p>
        </strong>
      </div>
      <div class="modal-footer">
        <a class="btn btn-outline-secondary" href="<?php echo e(route('fournisseurs.index')); ?>"> Non</a>
        
        <button type="button" class="btn btn-outline-success" data-dismiss="modal">Oui</button>
      </div>
    </div>
  </div>
</div>
</div>

<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:50%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-plus-circle"></i>  Ajouter nouveau fournisseur</h5>
        </div>
        <div class="card-block">

        <p style="font-weight:bold; margin-bottom : 30px;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

            <form class="form-material" action="<?php echo e(route('fournisseurs.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
           
                <div class="form-group form-primary form-static-label">
                    <input type="integer" name="code_fournisseur" class="form-control" placeholder="Entrer le code de fournisseur">
                    <span class="form-bar"></span>
                    <label class="float-label">Code de fournisseur <span class="text-danger">*</span> </label>
                </div>
                          
                  <div class="form-group form-primary form-static-label">
                    <input type="txt" name="intitule_fournisseur" class="form-control" placeholder="Entrer l'intitulé de fournisseur">
                    <span class="form-bar"></span>
                    <label class="float-label">Intitulé de fournisseur <span class="text-danger">*</span> </label>
                  </div>   
                
                <div class="form-group form-primary form-static-label">
                    <input type="tel" name="telephone_fournisseur" class="form-control" placeholder="Entrer le télephone de fournisseur">
                    <span class="form-bar"></span>
                    <label class="float-label">Télephone de fournisseur <span class="text-danger">*</span> </label>
                </div>

                                
                <div class="form-group form-primary form-static-label">
                    <input type="email" name="email_fournisseur" class="form-control" placeholder="Entrer l'email de fournisseur">
                    <span class="form-bar"></span>
                    <label class="float-label">Email de fournisseur <span class="text-danger">*</span> </label>
                </div>
        
                <div class=" text-right" style="margin-top: 10px;">
                <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-plus-circle"> </i> Ajouter</button>
                <button type="reset" class="btn btn-info" style="margin-left: 10px;"><i class="fa fa-fw fa-sync" ></i> Réinitialiser</button>
                 </div>
                                                 
            </form>
         </div>
    </div>
<!-- end formulaire -->

<!-- formulaire 
<div class="card">

		<div class="card-header"><i class="fa fa-fw fa-plus-circle"></i> <strong> Ajouter nouveau fournisseur</strong> </div>

			<div class="card-body">
                
				<div class="col-sm-8">

<form action="<?php echo e(route('fournisseurs.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
    <div class="row " >
        <div class="col-6">
            <div class="form-group">
                <strong>Code : <span class="text-danger">*</span></strong>
                <input type="text" name="codefournisseur" class="form-control" placeholder="Code">
            </div>
        </div>

        <div class="col-6">
            <div class="form-group">
                <strong>Intitulé : <span class="text-danger">*</span></strong>
                <input type="text" class="form-control" name="intitulefournisseur" placeholder="Intitulé ">
            </div>
        </div>
        </div>

        <div class="row justify-content-around">
       
        <div class="col-6">
            <div class="form-group">
                <strong>Télephone : <span class="text-danger">*</span></strong>
                <input type="telephone" class="form-control" name="telephonefournisseur" placeholder="Télephone">
            </div>
        </div>
        
        <div class="col-6">
            <div class="form-group">
                <strong>Email : <span class="text-danger">*</span></strong>
                <input type="email" class="form-control" name="emailfournisseur" placeholder="Email">
            </div>
        </div>
        </div>

        <div class=" text-right">
                <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-plus-circle"> </i> Ajouter</button>
                <button type="reset" class="btn btn-info" style="margin-left: 10px;"><i class="fa fa-fw fa-sync" ></i> Réinitialiser</button>
        </div>
    </div>
   
</form>
    </div>
            </div>
    </div>

   !-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fournisseurs.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/fournisseurs/create.blade.php ENDPATH**/ ?>