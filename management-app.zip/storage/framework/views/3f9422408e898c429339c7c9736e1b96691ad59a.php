

  
  <?php $__env->startSection('content'); ?>
    
  <div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
      <a class="btn btn-primary" href="<?php echo e(route('chantiers.listeOuvragesChantier')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
      <button class="btn btn-primary" type="button" onclick="PrintPage()" value="Imprimer" ><i class="fa fa-print" aria-hidden="true"></i>Imprimer</button>
     
  </div> 
  
  
  <div class="col d-flex justify-content-center" id="printableArea"> 
  
  <div style="width:90%" >
      <div class="card ">
  
      <div>
           <div style="margin:30px 15px 30px 15px;">
                      <h5 >Liste des ouvrages du chantier <?php echo e($chantier->intitule_chantier); ?> </h5>
            </div>
                      <table class="table m-b-0 text-center" >
                        <?php $__currentLoopData = $ouvrages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ouvrage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <thead style="font-weight:bold">
                            <tr>
                              <td>Code ouvrage</td> <td style="font-weight:normal"> <?php echo e($ouvrage->code_ouvrage); ?></td>
                              <td>Désignation d'ouvrage</td><td style="font-weight:normal"><?php echo e($ouvrage->designation_ouvrage); ?></td>
                              <td colspan="2" ></td>
                              
                            </tr>

                            <tr>
                                <td>Opération</td>
                                <td>Prix unitaire d'opération</td>
                                <td>Quantité opération</td>
                                <td>montant d'opération</td>
                                <td>Taux d'ajustement</td>
                                <td>montant net </td>
                            </tr>

                          </thead>
                              
                          
                          
                          <tbody >
  
                          <?php $__currentLoopData = $ouvrage->operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr >
                                  <td ><?php echo e($operation->designation_operation); ?> </td>
                                  <td> <?php echo e($operation->prix_unitaire); ?></td>
                                  <td ><?php echo e($operation->quantite_operation); ?> </td>
                                  <td ><?php echo e($operation->montant); ?> </td>
                                  <td ><?php echo e($operation->taux_ajustement); ?> </td>
                                  <td ><?php echo e($operation->montant_net); ?> </td>
                                  
                              </tr>
  
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td colspan="5" style="font-weight:bold" >Total ouvrage</td>
                                <td><?php echo e($ouvrage->total_ouvrage); ?></td>
                              </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td colspan="5" style="font-weight:bold">Total marché</td>
                            <td><?php echo e($chantier->total_marche); ?></td>
                        </tr>
                        </tbody>
                      </table>   
  
                   </div>  
  
           
      </div>
  </div>
  
  
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/chantiers/getOuvrages.blade.php ENDPATH**/ ?>