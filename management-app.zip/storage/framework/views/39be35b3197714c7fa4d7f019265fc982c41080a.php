
 
<?php $__env->startSection('content'); ?>

   

<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('materiels.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col  justify-content-center">    

	
<div class="blog-header py-1">
				<h3>Résultat de la recherche </h3>
</div>
		<div>
     
			<table class="table table-striped table-bordered text-center">
				<thead>
					<tr class="bg-primary text-white">
						<th >Code du matériel</th>
						<th >Intitule du matériel</th>
						<th >Action</th>
					</tr>
				</thead>
				<tbody>
                <?php $__currentLoopData = $materiels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materiel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($materiel->code_materiel); ?></td>
            <td><?php echo e($materiel->intitule_materiel); ?></td>
            <td>
               <a class="btn btn-info" href="<?php echo e(route('materiels.show',$materiel->id)); ?>" style="margin-left: 15px;"><i class="fa fa-fw fa-eye"></i>Consulter</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div> <!--/.col-sm-12-->
		

</div>





      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('materiels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/materiels/search.blade.php ENDPATH**/ ?>