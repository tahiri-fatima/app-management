
   
<?php $__env->startSection('content'); ?>
  
<div class="container " style="margin-left: 70%;"  > 
            <a class="btn btn-primary" href="<?php echo e(route('factures.show',$facture->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col  justify-content-center message" > 


<!-- Alert si le code est dupliqué !-->
<?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger">
        <p>    <strong>Whoops!</strong> Il y a dejà un enregistrement avec ce code de facture.<br><br> </p>
            
        </div>
    <?php endif; ?>
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>


<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:80%">  
        <div class="card-header">
            <h5> <i class="fa fa-fw fa-edit"></i>  Modifier la facture</h5>
        </div>
        <div class="card-block">

        <p style="font-weight:bold; margin-bottom : 30px;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>


        <form class="form-material" action="<?php echo e(route('factures.update',$facture->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

            <div class="row justify-content-around" >
                <div class="col-6">
                    <div class="form-group form-primary form-static-label">
                        <input type="text" name="code_facture"  value="<?php echo e($facture->code_facture); ?>" class="form-control" placeholder="Entrer le code de la facture">
                        <span class="form-bar"></span>
                        <label class="float-label">Code facture <span class="text-danger">*</span> </label>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group form-primary form-static-label">
                        <input type="date" name="date_facture"  value="<?php echo e($facture->date_facture); ?>" class="form-control">
                        <span class="form-bar"></span>
                        <label class="float-label">Date facture <span class="text-danger">*</span> </label>  
                    </div>
                </div>
            </div>

                <div class="row justify-content-around" >
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <input type="text" name="montant_facture"  value="<?php echo e($facture->montant_facture); ?>" class="form-control" placeholder="Entrer le montant de la facture">
                            <span class="form-bar"></span>
                            <label class="float-label">Montant facture <span class="text-danger">*</span> </label>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <input type="boolean" name="reglee" value="<?php echo e($facture->reglee); ?>" class="form-control" placeholder="Entrer 0 ou 1">
                            <span class="form-bar"></span>
                            <label class="float-label">Facture réglée <span class="text-danger">*</span> </label>
                        </div>
                    </div>
                </div>
               <div class="row">
                <div class="col-6">
                    <div class="form-group form-primary form-static-label">
                    <label class="select-label " >Commade <span class="text-danger">*</span> </label>
                        <div class="select">
                            <select class="form-control" name="commande_id">
                            <option value="<?php echo e($commande->id); ?>"><?php echo e($commande->code_commande); ?></option>
                                <?php $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($commande->id); ?>"><?php echo e($commande->code_commande); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>                
                        <span class="form-bar"></span> 
                    </div>
                </div>
               </div>
                <div class=" text-right">
                    <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
                  </div>
                                                 
            </form>
         </div>
    </div>
<!-- end formulaire -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('factures.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/factures/edit.blade.php ENDPATH**/ ?>