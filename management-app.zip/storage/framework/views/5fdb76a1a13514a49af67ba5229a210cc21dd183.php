
  
<?php $__env->startSection('content'); ?>
   
<div class="container text-right" > 
        <a class="btn btn-outline-primary text-right" href="<?php echo e(route('consommationMateriels.create')); ?>"><i class="fa fa-fw fa-plus-circle"></i> Ajouter nouvelle consommation matériel</a> 

        <a class="btn btn-outline-primary"  href="<?php echo e(route('consommationMateriels.edit',$consommationMateriel->id)); ?>" ><i class="fa fa-fw fa-edit"></i> Modifier</a>

      

        <button type="submit" class="btn btn-outline-primary" onclick="$('#modal').modal('show');" ><i class="fa fa-fw fa-trash"></i> Supprimer</button>
        <a class="btn btn-outline-primary" href="<?php echo e(route('consommationMateriels.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 

</div> 


<!-- modal pour confirmer la supression !-->
<div   class="modal" tabindex="-1" role="dialog" id="modal" >
  <div class="modal-dialog" role="document" >
  <form class="modal-content"action="<?php echo e(route('consommationMateriels.destroy',$consommationMateriel->id)); ?>" method="POST">
      <div class="modal-header" >
        <h5 class="modal-title" style="color:red;" > Confirmation de la supprission</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
          <strong >
            
            <p>Voulez vous supprimer la consommation dont le code <?php echo e($consommationMateriel->code_consommation_mat); ?> ?</p>
        </strong>
      </div>
      <div class="modal-footer">
     
        <button type="button" data-dismiss="modal" class="btn btn-outline-secondary" > Annuler</button>
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit"  class="btn btn-outline-danger"> Supprimer</button>
      </div>
  </form>
    </div>
  </div>


<div class="col d-flex justify-content-center"> 

<div class="col-xl-6 col-md-12 ">
    <div class="card table-card">

         <div class="card-header">
            <h5>Détails de la consommation du matériel <?php echo e($materiel->intitule_materiel); ?> </h5>
                <div class="card-header-right">
                    <ul class="list-unstyled card-option">
                        <li><i class="fa fa fa-wrench open-card-option"></i></li>
                        <li><i class="fa fa-window-maximize full-card"></i></li>
                        <li><i class="fa fa-minus minimize-card"></i></li>
                     </ul>
                </div>
            </div>
            
            <div class="card-block">
                <div class="table-responsive">
                    <table class="table table-hover m-b-0 without-header">
                        <tbody>
                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Code de la consommation : </h6> 
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($consommationMateriel->code_consommation_mat); ?></h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Quantité de la consommation : </h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($consommationMateriel->quantite_consommation_mat); ?></h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Date de la consommation :</h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($consommationMateriel->date_consommation_mat); ?> </h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6>Matériel consommé :</h6>
                                        </div>
                                    </div>
                                </td>
                                <td >
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><?php echo e($materiel->intitule_materiel); ?> </h6>
                                        </div>
                                    </div>
                                </td>
                            </tr>
 
                        </tbody>
                    </table>
                 </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('consommationMateriels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/consommationMateriels/show.blade.php ENDPATH**/ ?>