
   
<?php $__env->startSection('content'); ?>

<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('soutraitances.show',$soutraitance->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 
   
<div class="col d-flex justify-content-center" >
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
<!-- Alert si le code est dupliqué !-->
<?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un enregistrement avec ce code de sous traitance.<br><br>
            
        </div>
    <?php endif; ?>
</div>


<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:50%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-edit"></i>  Modifier sous traitance</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold; ">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

        <form class="form-material" action="<?php echo e(route('soutraitances.update',$soutraitance->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
                <div class="form-group form-primary form-static-label">
                <label class="float-label" style="top: -14px; font-size: 11px; color: #448aff;">Code de sous traitance<span class="text-danger">*</span> </label>
                    <input type="text" name="code_soutraitance" value="<?php echo e($soutraitance->code_soutraitance); ?>" class="form-control" placeholder="Entrer le code de sous traitance">
                    <span class="form-bar"></span>
                </div>

                <div class="form-group form-primary form-static-label">
                <label class="float-label" style="top: -14px; font-size: 11px; color: #448aff;">Intitulé de sous traitance<span class="text-danger">*</span> </label>
                    <input type="text" name="intitule_soutraitance" value="<?php echo e($soutraitance->intitule_soutraitance); ?>" class="form-control" placeholder="Entrer l'intitulé de sous traitance">
                    <span class="form-bar"></span>
                    
                </div>

                <div class="form-group form-primary form-static-label">
                <label class="float-label" style="top: -14px; font-size: 11px; color: #448aff;">Montant de sous traitance<span class="text-danger">*</span> </label>
                    <input type="double" name="montant_soutraitance" value="<?php echo e($soutraitance->montant_soutraitance); ?>" class="form-control" placeholder="Entrer le montant de sous traitance">
                    <span class="form-bar"></span>
                </div>

                <div class="form-group form-primary form-static-label">
                <label class="float-label" style="top: -14px; font-size: 11px; color: #448aff;">Date de sous traitance <span class="text-danger">*</span> </label>
                    <input type="date" name="date_soutraitance" value="<?php echo e($soutraitance->date_soutraitance); ?>" class="form-control">
                    <span class="form-bar"></span>
                </div>


                <div class=" text-right">
                    <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
                </div>
                                                 
            </form>
         </div>
    </div>

<!-- end Formulaire -->

    <!-- formulaire 
    <div class="card">

<div class="card-header"><strong> Modifier sous traitance </strong> </div>

    <div class="card-body">
        
        <div class="col-sm-8">

<form action="<?php echo e(route('soutraitances.update',$soutraitance->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>

   <div class="row " >
        <div class="col-6">
            <div class="form-group">
                <strong>Code : <span class="text-danger">*</span></strong>
                <input type="text" name="codesou_traitance" value="<?php echo e($soutraitance->codesou_traitance); ?>" class="form-control" placeholder="Code">
            </div>
        </div>

        <div class="col-6">
            <div class="form-group">
                <strong>Intitulé : <span class="text-danger">*</span></strong>
                <input type="text" class="form-control" value="<?php echo e($soutraitance->intitulesou_traitance); ?>" name="intitulesou_traitance" placeholder="Intitulé ">
            </div>
        </div>
        </div>

        <div class="row justify-content-around">
       
        <div class="col-6">
            <div class="form-group">
                <strong>Montant : <span class="text-danger">*</span></strong>
                <input type="decimal" class="form-control" value="<?php echo e($soutraitance->montantsou_traitance); ?>" name="montantsou_traitance" placeholder="Montant ">
            </div>
        </div>
        
        <div class="col-6">
            <div class="form-group">
                <strong>Date : <span class="text-danger">*</span></strong>
                <input type="date" class="form-control" value="<?php echo e($soutraitance->datesou_traitance); ?>" name="datesou_traitance" placeholder="Date ">
            </div>
        </div>
        </div>


<div class=" text-right">
        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
</div>
</div>

</form>
</div>
    </div>
</div>
!-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('soutraitances.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/soutraitances/edit.blade.php ENDPATH**/ ?>