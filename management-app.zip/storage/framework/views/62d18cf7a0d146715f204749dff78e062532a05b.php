


  
<?php $__env->startSection('content'); ?>

<div class="container " style="margin-left: 70%;" > 
            <a class="btn btn-primary" href="<?php echo e(route('personnels.show',$personnel->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col justify-content-center" >



<?php if($errors->any()): ?>
    <div class="alert alert-danger message">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger message">
         <p>   <strong>Whoops!</strong> Il y a dejà un personne avec ce code de personne.<br><br>  </p>
            
        </div>
    <?php endif; ?>

<!-- Affichage de modal si le personne ajouté avec succes. !-->
    <?php if(!empty(Session::get('success')) && Session::get('success') == 'Personne ajouté avec succes.'): ?>
    <script>
        $(function() {
            $('#myModal').modal('show');
        });
    </script>
    <?php endif; ?>

<!-- modal si Personne ajouté avec succes !-->
<div class="modal" tabindex="-1" role="dialog" id="myModal" >
  <div class="modal-dialog" role="document" >
    <div class="modal-content">
      <div class="modal-header" >
        <h5 class="modal-title" style="color:#228B22;" > Ajout avec succes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
          <strong >
            <p>Personne ajouté avec succes.</p>
            <p>Voulez vous insérer un autre personne ?</p>
        </strong>
      </div>
      <div class="modal-footer">
        <a class="btn btn-outline-secondary" href="<?php echo e(route('personnels.index')); ?>"> Non</a>
        
        <button type="button" class="btn btn-outline-success" data-dismiss="modal">Oui</button>
      </div>
    </div>
  </div>
</div>
</div>




<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:80%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-edit"></i>  Modifier le personnel</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold; margin-bottom : 30px;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

            <form class="form-material" action="<?php echo e(route('personnels.update',$personnel->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>

            <div class="row justify-content-around">
                 <div class="col-6">
                    <div class="form-group form-primary form-static-label">
                        <input type="text" name="code_personne" class="form-control" value="<?php echo e($personnel->code_personne); ?>" placeholder="Entrer le code du personnel">
                        <span class="form-bar"></span>
                        <label class="float-label">Code du personnel<span class="text-danger">*</span> </label>
                    </div>
                 </div>
                 <div class="col-6">
                    <div class="form-group form-primary form-static-label">
                        <input type="text" name="nom_personne" class="form-control" value="<?php echo e($personnel->nom_personne); ?>" placeholder="Entrer le nom du personnel">
                        <span class="form-bar"></span>
                        <label class="float-label">Nom du personnel<span class="text-danger">*</span> </label>
                    </div>
                 </div>
            </div>

            <div class="row justify-content-around">
                     <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <input type="text" name="prenom_personne" class="form-control" value="<?php echo e($personnel->prenom_personne); ?>" placeholder="Entrer le prénom du personnel">
                            <span class="form-bar"></span>
                            <label class="float-label">Prénom du personnel<span class="text-danger">*</span> </label>
                        </div>
                     </div>
                     <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                           <input type="text" name="qualification" class="form-control" value="<?php echo e($qual->designation_qual); ?>" placeholder="Entrer la qualification">
                            <span class="form-bar"></span>
                            <label class="float-label">Qualification<span class="text-danger">*</span> </label>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-around">
                     <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                           <input type="text" name="fonction" class="form-control" value="<?php echo e($personnel->fonction); ?>" placeholder="Entrer la foction">
                            <span class="form-bar"></span>
                            <label class="float-label">Fonction<span class="text-danger">*</span> </label>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <input type="text" name="num_cnss" class="form-control" value="<?php echo e($personnel->num_cnss); ?>" placeholder="Entrer le numéro de la CNSS">
                            <span class="form-bar"></span>
                            <label class="float-label">Numéro de la CNSS <span class="text-danger">*</span> </label>
                        </div>
                     </div>
                </div>

                <div class="row justify-content-around">
                     <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <input type="double" name="montant_cnss" class="form-control" value="<?php echo e($personnel->montant_cnss); ?>" placeholder="Entrer le montant de la CNSS">
                            <span class="form-bar"></span>
                            <label class="float-label">Montant de la CNSS<span class="text-danger">*</span> </label>
                        </div>
                     </div>
                     <div class="col-6">
                     <div class="form-group form-primary form-static-label">
                            <input type="date" name="date_embauche" class="form-control" value="<?php echo e($personnel->date_embauche); ?>">
                            <span class="form-bar"></span>
                            <label class="float-label">Date d'embauche<span class="text-danger">*</span> </label>
                        </div>
                     </div>
                    </div>
             


                <div class="row justify-content-around">
                     
                       

                     <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <input type="double" name="tele" class="form-control" value="<?php echo e($personnel->tele); ?>" placeholder="Entrer le numéro de téléphone">
                            <span class="form-bar"></span>
                            <label class="float-label">Numéro de téléphone<span class="text-danger">*</span> </label>
                        </div>
                    </div>
              

               
                    <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <label class="select-label " >Rôle <span class="text-danger">*</span> </label>
                                <div class="select">
                                    <select class="form-control" name="role_id" >
                                        <option value="<?php echo e($userRole->id); ?>"><?php echo e($userRole->name); ?></option>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>                
                            <span class="form-bar"></span> 
                        </div>
                    </div>
                </div>

         

                <div class=" text-right">
                    <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
                </div>
                                                 
            </form>
         </div>
    </div>

<!-- end Formulaire -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('personnels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/personnels/edit.blade.php ENDPATH**/ ?>