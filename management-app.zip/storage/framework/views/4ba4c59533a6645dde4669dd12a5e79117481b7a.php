
 
<?php $__env->startSection('content'); ?>

<div class="container" style=" width: 200%; ">
		<div class="card">
			<div class="card-body">
				
				<div >
					<h5 class="card-title"><i class="fa fa-fw fa-search"></i> Chercher réparation</h5>

                        <form class="form-material" type="get" action="<?php echo e(route('reparations.search')); ?>" >
                                <div class="row justify-content-center" >
                                    <div class="col-4">
                                        <div class="form-group"  >
                                            <input class="form-control mr-ms-2" name="code_reparation"  type="search" placeholder="Code de la réparation" >
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group"  >
                                            <input class="form-control mr-ms-2" name="intitule_reparation"  type="search" placeholder="Intitulé de la réparation" >
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group "  >
                                            <button class="btn btn-primary" type="submit" value="search" style="margin-right: 15px;" ><i class="fa fa-fw fa-search"></i> Chercher</button>
                                            <button type="reset" class="btn btn-info" > <i class="fa fa-fw fa-sync"></i> Réinitialiser</button>
                                        </div>
                                    </div>
                                </div>
                        </form>
                </div>
            </div>
        </div>
       </div>


       <div class="form-material">
		<div class="container" style="margin-top: 20px;margin-bottom: 20px;">
			
        <div class="text-right"> 
            <a class="btn btn-primary text-right" href="<?php echo e(route('reparations.create')); ?>"><i class="fa fa-fw fa-plus-circle"></i> Ajouter nouvelle réparation</a> 
            <a class="btn btn-primary text-right" href="/" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
        </div> 

		</div> <!--/.container-->

        <h5 style="margin-left: 25px; margin-bottom: 15px;" >Gestion des réparations</h5>

        <div class="col  justify-content-center">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>

        <div class="row " style="margin-left: 30px;" >
            <div class="col-6">
                <div class="form-group form-primary form-static-label">
                    <select class="form-control" id="reparations" type="dropdown-toggle" class="form-control" name="reparations" onchange="top.location.href = this.options[this.selectedIndex].value" >
                        <option value="choisir" selected disabled>Choisir réparation</option>
                        <?php $__currentLoopData = $reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="reparations" value="<?php echo e(route('reparations.show',$reparation->id)); ?>"><?php echo e($reparation->intitule_reparation); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>                
                <span class="form-bar"></span>
                     
            </div>
        </div>


</div>
	

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('reparations.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/reparations/index.blade.php ENDPATH**/ ?>