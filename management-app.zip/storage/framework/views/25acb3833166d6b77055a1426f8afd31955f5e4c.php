

  
  <?php $__env->startSection('content'); ?>
    
  <div class=" text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
      <a class="btn btn-primary" href="<?php echo e(route('chantierMateriels.DetailPrixMaterielChantier')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
      <button class="btn btn-primary" type="button" onclick="PrintPage()" value="Imprimer" ><i class="fa fa-print" aria-hidden="true"></i>Imprimer</button>
  </div> 
  
  
  
  <div class="col d-flex justify-content-center" id="printableArea"> 
  
  <div style="width:90%" >
      <div class="card ">
  
      <div>
      <div class="text-center">
           <img class="img" src="<?php echo e(url('assets/images/logo.png')); ?>"  style="width: 170px; height: 70px; margin-top:25px " />

                      <h5 style="margin:30px 15px 30px 15px; text-align:center">Détail des prix élémentaires des matériels du chantier <?php echo e($chantier->intitule_chantier); ?> </h5>
                      
            </div>
                      <table class="table m-b-0 text-center" >
                          <thead style="font-weight:bold">
                              
                              <td>Désignation du Matériel</td>
                              <td>Type</td>
                              <td>Quantité</td>
                              <td>Prix unitaire</td>
                              <td>Durée</td>                              
                              <td>Montant</td>

                          </thead>
                          <tbody >
  
                          <?php $__currentLoopData = $materiels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materiel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr >
                                  <td ><?php echo e($materiel->intitule_materiel); ?> </td>
                                  <td ><?php echo e($materiel->type); ?> </td>
                                  <td> <?php echo e($materiel->prix_unit); ?></td>
                                  <td ><?php echo e($materiel->duree); ?> </td>
                                  <td ><?php echo e($materiel->quantite); ?> </td>
                                  <td ><?php echo e($materiel->mont_net); ?> </td>
                              </tr>

                             
  
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                                  <td class="text-center" colspan="5" style="font-weight:bold"> Total géneral </td>
                                  <td><?php echo e($chantier->total); ?></td>
                              </tr>
                            
                          </tbody>
                      </table>   
  
                   </div>  
  
           
      </div>
  </div>
  
  
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/edition/DetailPrixMateriel.blade.php ENDPATH**/ ?>