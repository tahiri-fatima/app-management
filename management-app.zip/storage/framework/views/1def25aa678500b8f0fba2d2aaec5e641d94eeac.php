


  
<?php $__env->startSection('content'); ?>

 
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('ordreServices.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col justify-content-center" >

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un ordre de service avec ce code.<br><br>
            
        </div>
    <?php endif; ?>

<!-- Affichage de modal si la ordreServices ajouté avec succes. !-->
    <?php if(!empty(Session::get('success')) && Session::get('success') == 'OrdreService ajouté avec succes.'): ?>
    <script>
        $(function() {
            $('#myModal').modal('show');
        });
    </script>
    <?php endif; ?>

<!-- modal si l'ordre est ajouté avec succes !-->
<div class="modal" tabindex="-1" role="dialog" id="myModal" >
  <div class="modal-dialog" role="document" >
    <div class="modal-content">
      <div class="modal-header" >
        <h5 class="modal-title" style="color:#228B22;" > Ajout avec succes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
          <strong >
            <p>Enregistrement ajoutée avec succes.</p>
            <p>Voulez vous insérer un autre Enregistrement ?</p>
        </strong>
      </div>
      <div class="modal-footer">
        <a class="btn btn-outline-secondary" href="<?php echo e(route('ordreServices.index')); ?>"> Non</a>
        
        <button type="button" class="btn btn-outline-success" data-dismiss="modal">Oui</button>
      </div>
    </div>
  </div>
</div>
</div>

<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:50%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-plus-circle"></i>  Ajouter nouveau ordre de service</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold; margin-bottom : 30px;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

            <form class="form-material" action="<?php echo e(route('ordreServices.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
                    <div class="form-group form-primary form-static-label">
                        <input type="text" name="code_ordre_serv" class="form-control" placeholder="Entrer le code d'ordre de service">
                        <span class="form-bar"></span>
                        <label class="float-label">Code d'ordre de service <span class="text-danger">*</span> </label>
                    </div>
                
                    <div class="form-group form-primary form-static-label">
                        <input type="text" name="type_ordre_serv" class="form-control" placeholder="Entrer le type d'ordre de service">
                        <span class="form-bar"></span>
                        <label class="float-label">Type d'ordre de service <span class="text-danger">*</span> </label>  
                    </div>
               
                        <div class="form-group form-primary form-static-label">
                            <input type="date" name="date_ordre_serv" class="form-control" >
                            <span class="form-bar"></span>
                            <label class="float-label">Date d'ordre de service <span class="text-danger">*</span> </label>
                        </div>
                    
                        <div class="form-group form-primary form-static-label">
                        <label class="form-label " style="top: -14px; font-size: 11px; color: #448aff;">Chantier <span class="text-danger">*</span> </label>
                            <div class="select">
                            <select class="form-control" name="chantier_id">
                            <option value="">Selectionner Chantier</option>
                                <?php $__currentLoopData = $chantiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chantier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($chantier->id); ?>"><?php echo e($chantier->intitule_chantier); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>                
                            <span class="form-bar"></span> 
                        </div>
                  

                <div class=" text-right" style="margin-top: 10px;">
                <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-plus-circle"> </i> Ajouter</button>
                <button type="reset" class="btn btn-info" style="margin-left: 10px;"><i class="fa fa-fw fa-sync" ></i> Réinitialiser</button>
                 </div>
                                                 
            </form>
         </div>
    </div>
<!-- end formulaire -->

<!-- formulaire 
<div class="card">

		<div class="card-header"><i class="fa fa-fw fa-plus-circle"></i> <strong> Ajouter nouveau ordre</strong> </div>

			<div class="card-body">
                
				<div class="col-sm-8">

<form action="<?php echo e(route('ordreServices.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
    <div class="row justify-content-around " >
        <div class="col-6">
            <div class="form-group">
            <label >  <strong>Code : <span class="text-danger">*</span></strong></label>
                <input type="text" class="form-control" name="codeordreserv"  placeholder="Code">
            </div>
        </div>
    
        <div class="col-6">
            <div class="form-group">
            <label>  <strong>Type : <span class="text-danger">*</span></strong></label>
                <input type="text" class="form-control" name="typeordreserv" placeholder="Type d'ordre">
            </div>
        </div>
    </div>

    <div class="row justify-content-around"> 
        <div class="col-6">
            <div class="form-group">
            <label > <strong>Date : <span class="text-danger">*</span></strong></label>
                <input type="date" class="form-control" name="dateordreserv" placeholder="Date d'ordre">
            </div>
        </div>
     
     <div class="col-6">
            <div class="form-group">
                <label><strong>Chantier : <span class="text-danger">*</span></strong></label>
                <div class="select">
                <select class="form-control" name="chantier_id">
                    <option value="">Selectionner Chantier</option>
                    <?php $__currentLoopData = $chantiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chantier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($chantier->id); ?>"><?php echo e($chantier->intitulechantier); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
            </div>
        </div>
     </div>

        <div class=" text-right">
                <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-plus-circle"> </i> Ajouter</button>
                <button type="reset" class="btn btn-info" style="margin-left: 10px;"><i class="fa fa-fw fa-sync" ></i> Réinitialiser</button>
        </div>
    </div>
   
</form>
    </div>
            </div>
    </div>

   !-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ordreServices.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/ordreServices/create.blade.php ENDPATH**/ ?>