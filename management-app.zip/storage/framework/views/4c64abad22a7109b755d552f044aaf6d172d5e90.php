<!DOCTYPE html>
<html >

<head>
    <title>Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon">
    <!-- Google font-->
    <!-- waves.css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/pages/waves/css/waves.min.css')); ?>" type="text/css" media="all">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap/css/bootstrap.min.css')); ?>">
    <!-- waves.css -->
    <link rel="stylesheet" href=" <?php echo e(asset('assets/pages/waves/css/waves.min.css')); ?> " type="text/css" media="all">
    <!-- themify icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/icon/themify-icons/themify-icons.css')); ?>">
    <!-- font-awesome-n -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font-awesome-n.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <!-- scrollbar.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/jquery.mCustomScrollbar.css')); ?>">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>"  media="screen" >
    <!-- Impression.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/impression.css')); ?>" media="print">

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />





</head>

<body>
    <!-- Pre-loader start -->
    
    <!-- Pre-loader end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">
            <nav class="navbar header-navbar pcoded-header">
               
            </nav>

            <div class="pcoded-main-container">
 
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="page-header-title">
                                            <h5 class="m-b-10">
                                            <?php

                                            use Illuminate\Support\Facades\Request;

                                        $route = Request::route()->getName();

                                            if($route == ""){
                                                $page = "Page d'accueil";
                                            }
                                            elseif($route == "fournisseurs.listeCommandesFournisseur"){
                                                $page = "Liste des fournisseurs";
                                            }elseif($route == "chantiers.listeMaterielsChantier"){
                                                $page = "Liste des chantiers";
                                            }elseif($route == "chantiers.listeOuvragesChantier"){
                                                $page = "Liste des chantiers";
                                            }elseif($route == "commandes.listeMateriauxCommande"){
                                                $page = "Liste des commandes";
                                            }elseif($route == "commandes.liste"){
                                                $page = "Liste des commandes";
                                            }elseif($route == "chantiers.getMateriels"){
                                                $page = "Liste des matériels de chantier";
                                            }elseif($route == "chantiers.getOuvrages"){
                                                $page = "Liste des ouvrages de chantier";
                                            }elseif($route == "commandes.getMateriaux"){
                                                $page = "Liste des Matériaux de commande";
                                            }elseif($route == "fournisseurs.getCommandes"){
                                                $page = "Liste des commandes de fournisseur";
                                            }
                                            ?>
                                            <?php echo e($page); ?>

                                        </h5>
                                            <p class="m-b-0"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="/"> <i class="fa fa-home"></i> </a>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="page-body">
                        <?php echo $__env->yieldContent('content'); ?> 

                        </div>

            </div>
        </div>
        
    </div>
    <div style="margin-top:50px;">
   

    </div>

    <script type="text/javascript" src=" <?php echo e(asset('assets/js/jquery/jquery.min.js')); ?> "></script>
    <script type="text/javascript" src=" <?php echo e(asset('assets/js/jquery-ui/jquery-ui.min.js')); ?> "></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/popper.js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap/js/bootstrap.min.js')); ?> "></script>
    <!-- waves js -->
    <script src="<?php echo e(asset('assets/pages/waves/js/waves.min.js')); ?>"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>

    <!-- slimscroll js -->
    <script src="<?php echo e(asset('assets/js/jquery.mCustomScrollbar.concat.min.js')); ?> "></script>

    <!-- menu js -->
    <script src="<?php echo e(asset('assets/js/pcoded.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vertical/vertical-layout.min.js')); ?> "></script>

    <script type="text/javascript" src="<?php echo e(asset('assets/js/script.js')); ?> "></script>

    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


</body>

</html>


<?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>