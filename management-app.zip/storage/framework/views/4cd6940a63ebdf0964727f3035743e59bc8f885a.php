<!doctype html>
<html>
<head>
<meta charset="UTF-8">
	<title>Gestion des personnels</title>
	
</head>
<body>



<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/personnels/layout.blade.php ENDPATH**/ ?>