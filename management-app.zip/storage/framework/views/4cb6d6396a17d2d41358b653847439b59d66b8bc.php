
 
<?php $__env->startSection('content'); ?>

<div class="container" style=" width: 200%; ">
    <div class="card">
        <div class="card-body">
            
            <div >
                <h5 class="card-title"><i class="fa fa-fw fa-search"></i> Chercher Avenant</h5>

                    <form class="form-material" type="get" action="<?php echo e(route('avenants.search')); ?>" >
                            <div class="row" >
                                <div class="col-6">
                                    <div class="form-group" style="margin-right: 15px;" >
                                        <input class="form-control mr-ms-2" name="codeavenant"  type="search" placeholder="Code d'avenant" >
                                    </div>
                                </div>
                                <div class="col-6">
                                        <div class="form-group " style="margin-right: 15px;" >
                                            <button class="btn btn-primary" type="submit" value="search" style="margin-right: 15px;" ><i class="fa fa-fw fa-search"></i> Chercher</button>
                                            <button type="reset" class="btn btn-info" > <i class="fa fa-fw fa-sync"></i> Réinitialiser</button>
                                            </div>
                                </div>
                            </div>
                    </form>
            </div>
        </div>
    </div>
</div>



<div class="form-material">
		<div class="container" style="margin-top: 20px;margin-bottom: 20px;">
			
        <div class="text-right"> 
            <a class="btn btn-primary text-right" href="<?php echo e(route('avenants.create')); ?>"><i class="fa fa-fw fa-plus-circle"></i> Ajouter nouveau avenant</a> 
            <a class="btn btn-primary text-right" href="/" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
        </div> 

		</div> <!--/.container-->

        <h5 style="margin-left: 25px; margin-bottom: 15px;" >Gestion des avenants</h5>

        <div class="col  justify-content-center">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>

        <div class="row " style="margin-left: 30px;" >
            <div class="col-6">
                <div class="form-group form-primary form-static-label">
                    <select class="form-control" id="avenants" type="dropdown-toggle" class="form-control" name="avenants" onchange="top.location.href = this.options[this.selectedIndex].value" >
                        <option value="choisir" selected disabled>Choisir Avenant</option>
                        <?php $__currentLoopData = $avenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="avenants" value="<?php echo e(route('avenants.show',$avenant->id)); ?>"><?php echo e($avenant->code_avenant); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>                
                <span class="form-bar"></span>
                     
            </div>
        </div>


</div>



      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('avenants.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/avenants/index.blade.php ENDPATH**/ ?>