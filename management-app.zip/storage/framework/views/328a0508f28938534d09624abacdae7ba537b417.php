
   
<?php $__env->startSection('content'); ?>

<div class="container " style="margin-left:70%"> 
            <a class="btn btn-primary" href="<?php echo e(route('acomptes.show',$acompte->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 
<div class="col d-flex justify-content-center" > 
   <!-- Alert si le code est dupliqué !-->
   <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger message">
            <strong>Whoops!</strong> Il y a dejà un enregistrement avec ce code.<br><br>
            
        </div>
    <?php endif; ?>


    <?php if($errors->any()): ?>
        <div class="alert alert-danger message">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
  </div>
  
<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:70%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-edit"></i>  Modifier l'acompte</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold; margin-bottom : 30px;">Les champs avec <span class="text-danger">*</span> sont obligatoire!</p>

            <form class="form-material" action="<?php echo e(route('acomptes.update',$acompte->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row justify-content-around" >
                <div class="col-6">
                        <div class="form-group form-primary form-static-label">
                            <input type="text" name="code_acompte" class="form-control" value="<?php echo e($acompte->code_acompte); ?>" placeholder="Entrer le code d'acompte">
                            <span class="form-bar"></span>
                            <label class="float-label">Code d'acompte <span class="text-danger">*</span> </label>
                        </div>
                </div>
                    <div class="col-6">
                    <div class="form-group form-primary form-static-label">
                        <input type="date" name="date_acompte" class="form-control" value="<?php echo e($acompte->date_acompte); ?>">
                        <span class="form-bar"></span>
                        <label class="float-label">Date d'acompte <span class="text-danger">*</span> </label>
                    </div>
                    </div>
            </div>
                <div class="row justify-content-around" >
        <div class="col-6">
                <div class="form-group form-primary form-static-label">
                    <input type="text" name="montant_acompte" class="form-control" value="<?php echo e($acompte->montant_acompte); ?>" placeholder="Entrer le montant d'acompte">
                    <span class="form-bar"></span>
                    <label class="float-label">Montant d'acompte <span class="text-danger">*</span> </label>
                </div>
        </div>
                <div class="col-6">
                <div class="form-group form-primary form-static-label">
                    <input type="text" name="type_reglement" class="form-control" value="<?php echo e($acompte->type_reglement); ?>" placeholder="Entrer le type de réglement d'acompte">
                    <span class="form-bar"></span>
                    <label class="float-label">Type de réglement d'acompte <span class="text-danger">*</span> </label>
                </div>
                </div>
                </div>
        <div class="row ">
                <div class="col-6">
                <div class="form-group form-primary form-static-label">
                <label class="select-label " >Facture <span class="text-danger">*</span> </label>
                    <div class="select">
                        <select class="form-control" name="facture_id"  >
                        <option  value="<?php echo e($facture->id); ?>"><?php echo e($facture->code_facture); ?></option>
                            <?php $__currentLoopData = $factures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($facture->id); ?>"><?php echo e($facture->code_facture); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>                
                     <span class="form-bar"></span>
                </div> 
                </div>

               
        </div>
               
                <div class=" text-right">
                        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Modifier</button>
                </div>                         
            </form>
         </div>
    </div>
<!-- end formulaire-->
</div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('acomptes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/acomptes/edit.blade.php ENDPATH**/ ?>