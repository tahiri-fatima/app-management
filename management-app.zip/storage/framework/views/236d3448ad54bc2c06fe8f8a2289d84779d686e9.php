
 
<?php $__env->startSection('content'); ?>

<div class="col d-flex justify-content-center">

<div class="container">
		<div class="card">
			<div class="card-body">
				
				<div >
					<h5 class="card-title"><i class="fa fa-fw fa-search"></i> Chercher décompte</h5>

                        <form class="form-material" type="get" action="<?php echo e(route('decomptes.search')); ?>" >
                        <div class="row justify-content-center" >
                                <div class="col-6">
                                    <div class="form-group" style="margin-right: 15px;" >
                                        <input class="form-control mr-ms-2" name="num_decompte"  type="search" placeholder="Numéro de décompte" >
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group " style="margin-right: 15px;" >
                                        <button class="btn btn-primary" type="submit" value="search" style="margin-right: 15px;" ><i class="fa fa-fw fa-search"></i> Chercher</button>
                                        <button type="reset" class="btn btn-info" > <i class="fa fa-fw fa-sync"></i> Réinitialiser</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                </div>
            </div>
        </div>
       </div>
</div>
       <div class="form-material">
		<div class="container" style="margin-top: 20px;margin-bottom: 20px;">
			
        <div style="margin-left: 50%;"> 
            <a class="btn btn-primary text-right" href="<?php echo e(route('decomptes.create')); ?>"><i class="fa fa-fw fa-plus-circle"></i> Ajouter nouveau décompte</a> 
            <a class="btn btn-primary text-right" href="home" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
        </div> 

		</div> <!--/.container-->
        <div class="col d-flex justify-content-center " > 
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success message">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>

            <?php if($message = Session::get('warning')): ?>
            <div class="alert alert-info message">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>

            <?php if($message = Session::get('error')): ?>
            <div class="alert alert-danger message">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
        </div>

        <h5 style="margin-left: 25px; margin-bottom: 15px;" >Gestion des décomptes</h5>

        <div class="col  justify-content-center">
       

        <div class="row " style="margin-left: 30px;" >
            <div class="col-6">
                <div class="form-group form-primary form-static-label">
                    <select class="form-control" id="decomptes" type="dropdown-toggle" class="form-control" name="decomptes" onchange="top.location.href = this.options[this.selectedIndex].value" >
                        <option value="choisir" selected disabled>Choisir Décompte</option>
                        <?php $__currentLoopData = $decomptes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decompte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="decomptes" value="<?php echo e(route('decomptes.show',$decompte->id)); ?>"><?php echo e($decompte->num_decompte); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>                
                <span class="form-bar"></span>
                     
            </div>
        </div>


</div>
	

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('decomptes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/decomptes/index.blade.php ENDPATH**/ ?>