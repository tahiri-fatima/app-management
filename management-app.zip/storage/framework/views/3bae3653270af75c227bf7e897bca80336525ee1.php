
 
<?php $__env->startSection('content'); ?>


  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('decomptes.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col  justify-content-center">    

<div class="blog-header py-1">
				<h3>Résultat de la recherche </h3>
</div>
		<div>
     
			<table class="table table-striped table-bordered text-center">
            <thead>
					<tr class="bg-primary text-white">
					    <th >Numéro du décompte</th>
						<th >Date du décompte</th>
                        <th >Montant du décompte</th>
						<th >Action</th>
					</tr>
				</thead>
				<tbody>
                <?php $__currentLoopData = $decomptes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decompte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($decompte->num_decompte); ?></td>
            <td><?php echo e($decompte->date_decompte); ?></td>
            <td><?php echo e($decompte->montant_decompte); ?></td>
            <td>
               <a class="btn btn-info" href="<?php echo e(route('decomptes.show',$decompte->id)); ?>" style="margin-left: 15px;"><i class="fa fa-fw fa-eye"></i>Consulter</a>
    
                   
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div> <!--/.col-sm-12-->
		
</div>
   





      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('decomptes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/decomptes/search.blade.php ENDPATH**/ ?>