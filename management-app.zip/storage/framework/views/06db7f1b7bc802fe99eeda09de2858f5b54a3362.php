
 
<?php $__env->startSection('content'); ?>

  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('chantierMateriels.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col  justify-content-center">  
<div>
<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>  
</div>

<div class="blog-header py-1">
				<h3>Résultat de la recherche </h3>
</div>
		<div>
     
			<table class="table table-striped table-bordered text-center">
                 <thead>
					
			<table class="table table-striped table-bordered text-center">
            
				<thead>
					<tr class="bg-primary text-white">
                    <th >Code du chantier</th>
						<th >Code du Matériel</th>
						<th >Action</th>
					</tr>
				</thead>
				<tbody>
                <?php if($chantierMateriels != null): ?>
                    <?php $__currentLoopData = $chantierMateriels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chantierMateriel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($chantierMateriel->chantier()->code_chantier); ?></td>
                            <td><?php echo e($chantierMateriel->materiel()->code_materiel); ?></td>
                            <td>
                                <a class="btn btn-info" href="<?php echo e(route('chantierMateriels.showMateriels',$chantierMateriel->chantier()->id)); ?>" style="margin-left: 15px;"><i class="fa fa-fw fa-eye"></i> Consulter</a>

                            </td>
                        </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
				</tbody>
			</table>
		</div> <!--/.col-sm-12-->
		

</div>





      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('chantierMateriels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/chantierMateriels/search.blade.php ENDPATH**/ ?>