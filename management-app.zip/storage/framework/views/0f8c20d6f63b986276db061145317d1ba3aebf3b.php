<!doctype html>
<html>
<head>
<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>chantier_matériel</title>
	
   </head>
<body>




<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="pcoded-content">
            <?php echo $__env->yieldContent('content'); ?>

            </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/chantierOverages/layout.blade.php ENDPATH**/ ?>