
 
<?php $__env->startSection('content'); ?>

<div class="container " style="margin-left: 50%; margin-top: 50px;">
       <form type="get" action=" <?php echo e(route('chantiers.searchMateriauxByChantier')); ?> " >
           <div class="form-group " style="display: flex;">
                <div class="searchbar">
                    <input class="search_input" type="text" name="codechantier" placeholder="Chercher avec le code de chantier ">
                    <button class="btn search_icon" type="submit" value="search" style="border: none; background-color: #77d5fb;" ><i class="fas fa-search"></i> </button>
                </div>
                <div style="margin-left: 15px ;" >
                    <a class="btn btn-primary " href="home" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
                </div>
           </div>
        </form>   
</div>



       
<div class="form-material" style="margin-top: 20px;margin-bottom: 20px;margin-left: 50px;">



        <div class="col d-flex justify-content-center">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success message">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>

        <?php if($message = Session::get('warning')): ?>
        <div class="alert alert-info message">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        </div>
        <div class="col  justify-content-center ">
        <h5 class="m-b-20 m-l-30"  >Sélectionner un chantier pour afficher ses matériaux </h5>

        <div class="row " style="margin-left: 30px;" >
            <div class="col-6">
                <div class="form-group form-primary form-static-label">
                    <select class="form-control" id="chantiers" type="dropdown-toggle" class="form-control" name="chantiers" onchange="top.location.href = this.options[this.selectedIndex].value" >
                        <option value="choisir" selected disabled>Choisir chantier</option>
                        <?php $__currentLoopData = $chantiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chantier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="chantiers" value="<?php echo e(route('commandesMateriaus.DetailPrixMateriaux',$chantier->id)); ?>"><?php echo e($chantier->intitule_chantier); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>                
                <span class="form-bar"></span>
                     
            </div>
        </div>


</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/edition/DetailPrixMateriauxByChantier.blade.php ENDPATH**/ ?>