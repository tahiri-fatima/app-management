
  
<?php $__env->startSection('content'); ?>


<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 70px; "> 
        <a class="btn btn-outline-primary text-right" href="<?php echo e(route('operationOverages.create')); ?>"><i class="fa fa-fw fa-plus-circle"></i> Ajouter nouveau ouvrage-opérations</a> 

        <a class="btn btn-outline-primary"  href="<?php echo e(route('operationOverages.editOperations',$ouvrage->id)); ?>" ><i class="fa fa-fw fa-edit"></i> Modifier</a>

       <a class="btn btn-outline-primary" href="<?php echo e(route('operationOverages.index')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 

</div> 



<div class="col d-flex justify-content-center"> 

<div style="width: 90%;" >
    <div class="card " >

         <div class="card-header">
            <h5>Détails d'ouvrage-opérations</h5>
                <div class="card-header-right">
                    <ul class="list-unstyled card-option">
                        <li><i class="fa fa fa-wrench open-card-option"></i></li>
                        <li><i class="fa fa-window-maximize full-card"></i></li>
                        <li><i class="fa fa-minus minimize-card"></i></li>
                     </ul>
                </div>
            </div>
            
            <div class="card-block">
                <div class="table-responsive">
                    <table class="table  m-b-0 without-header">
                        <tbody>
                            <tr>
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6> <span style="font: size 16px; color:#0d46a1;">Code d'ouvrage : </span>  <?php echo e($ouvrage->code_ouvrage); ?></h6>
                                        </div>
                                    </div>
                                </td>
                             
                                <td>
                                    <div class="d-inline-block align-middle">
                                        <div class="d-inline-block">
                                            <h6><span style="font: size 16px; color:#0d46a1;">Désignation d'ouvrage : </span>  <?php echo e($ouvrage->designation_ouvrage); ?> </h6>
                                        </div>
                                    </div>
                                </td>
                                
                            </tr>
                          
                            <table class="table table-hover m-b-0 text-center">
                                <thead >
                                    <tr style="font: size 16px; color:#0d46a1;">
                                        <th >Code d'opération</th>
                                        <th >Désignation d'opération</th>
                                        <th >Prix unitaire d'opération</th>
                                        <th >Quantité </th>
                                        <th >Taux d'ajustement</th>
                                        <th >Montant net </th>
                                    </tr>
                                </thead>
                            
                            <?php $__currentLoopData = $ouvrage->operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td ><h6><?php echo e($operation->code_operation); ?> </h6></td>
                                    <td ><h6><?php echo e($operation->designation_operation); ?> </h6></td>
                                    <td ><h6><?php echo e($operation->prix_unitaire); ?> </h6></td>
                                    <td ><h6><?php echo e($operation->quantite_operation); ?> </h6></td>
                                    <td ><h6><?php echo e($operation->taux_ajustement); ?> </h6></td>
                                    <td ><h6><?php echo e($operation->montant_net); ?> </h6></td>
                                </tr>
                                
                              
                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                  <td colspan="5"><h6>Montant net total </h6></td>
                                  <td><h6><?php echo e($ouvrage->total); ?> </h6></td>
                              </tr>
                            </table>
                            </table>
                            
                           
                            
                        </tbody>
                    </table>
                 </div>
            </div>
        </div>
    </div>
</div>  














<?php $__env->stopSection(); ?>
<?php echo $__env->make('operationOverages.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/operationOverages/show.blade.php ENDPATH**/ ?>