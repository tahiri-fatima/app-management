
   
<?php $__env->startSection('content'); ?>


  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('chantierOverages.showOuvrages', $chantier->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col d-flex justify-content-center" > 
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un enregistrement avec ce code ce couple de code chantier et ouvrage.<br><br>
            
        </div>
    <?php endif; ?>


</div>
<div class="col d-flex justify-content-center" > 

<!-- start Formulaire -->


    <div class="card" style="width:70%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-edit"></i>  Modifier le couple chantier ouvrage</h5>
        </div>
        <div class="card-block">
        <p style="font-weight:bold;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

            <form action="<?php echo e(route('chantierOverages.updateOuvrages',$chantier->id)); ?>" >
                <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row justify-content-around" >
                <div class="col-6">
                    <div class="form-group form-primary form-static-label">
                        <label class="form-label " style="top: -14px; font-size: 11px; color: #448aff;">Chantier <span class="text-danger">*</span> </label>
                            <div class="select">
                                <select class="form-control" name="chantier_id" >
                                <option value="<?php echo e($chantier->id); ?>"><?php echo e($chantier->intitule_chantier); ?></option>
                                    <?php $__currentLoopData = $chantiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chantier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($chantier->id); ?>"><?php echo e($chantier->intitule_chantier); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>                
                        <span class="form-bar"></span>    
                    </div>
                </div>

                <div class="col-6">
                    <div class="multi-select" >
                        <label  style="top: -14px; font-size: 11px; color: #448aff;">Ouvrages <span class="text-danger">*</span> </label>
                        <div class="select" >
                            <select id="mySelect" class="overages" name="ouvrages[]" multiple size="5" style="width: 100%;" >
                                <?php $__currentLoopData = $ouvrages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ouvrage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(in_array($ouvrage->id , $overages)): ?>
                                        <option value="<?php echo e($ouvrage->id); ?>" selected="true"><?php echo e($ouvrage->designation_ouvrage); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($ouvrage->id); ?>"> <?php echo e($ouvrage->designation_ouvrage); ?>  </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>                                                                   
                    </div>
                </div>  
            </div>
                    <div class=" text-right">
                        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Modifier</button>
                    </div>
            </form>
         </div>
    </div>
</div>
<!-- end Formulaire -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('chantierOverages.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/chantierOverages/edit.blade.php ENDPATH**/ ?>