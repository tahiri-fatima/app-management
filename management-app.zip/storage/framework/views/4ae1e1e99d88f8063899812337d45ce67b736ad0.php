<!DOCTYPE html>
<html >

<head>
    <title>Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon">
    <!-- Google font-->
    <!-- waves.css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/pages/waves/css/waves.min.css')); ?>" type="text/css" media="all">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap/css/bootstrap.min.css')); ?>">
    <!-- waves.css -->
    <link rel="stylesheet" href=" <?php echo e(asset('assets/pages/waves/css/waves.min.css')); ?> " type="text/css" media="all">
    <!-- themify icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/icon/themify-icons/themify-icons.css')); ?>">
    <!-- font-awesome-n -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font-awesome-n.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <!-- scrollbar.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/jquery.mCustomScrollbar.css')); ?>">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>"  media="screen" >
    <!-- Impression.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/impression.css')); ?>" media="print">

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />





</head>

<body>
    <!-- Pre-loader start -->
    
    <!-- Pre-loader end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">
            <nav class="navbar header-navbar pcoded-header">
                <div class="navbar-wrapper">
                    <div class="navbar-logo">
                        <a class="mobile-menu waves-effect waves-light" id="mobile-collapse" type="get" >
                            <i class="ti-menu"></i>
                        </a>
                        <div class="mobile-search waves-effect waves-light">
                            <div class="header-search">
                                <div class="main-search morphsearch-search">
                                    <div class="input-group">
                                        <span class="input-group-prepend search-close"><i class="ti-close input-group-text"></i></span>
                                        <input type="text" class="form-control" placeholder="Enter Keyword" name="page"  type="search">
                                        <span class="input-group-append search-btn"><i class="ti-search input-group-text"></i></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <a class="mobile-options waves-effect waves-light">
                            <i class="ti-more"></i>
                        </a>
                    </div>
                    <div class="navbar-container container-fluid">
                        <ul class="nav-left">
                            <li>
                                <div class="sidebar_toggle"><a href="javascript:void(0)"><i class="ti-menu"></i></a></div>
                            </li>
                            <li>
                                <a href="#!" onclick="javascript:toggleFullScreen()" class="waves-effect waves-light">
                                    <i class="ti-fullscreen"></i>
                                </a>
                            </li>
                        </ul>
                        
                    </div>
                </div>
            </nav>

            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                    <nav class="pcoded-navbar">
                        <div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
                        <div class="pcoded-inner-navbar main-menu">
                            <div class="">
                                <div class="main-menu-header">  
                                    <h3 style="color:white;"> Gestion des données </h3>
                                </div>
                                
                            

                            <div class="pcoded-navigation-label" id="sidebar">Navigation</div>
                            <ul class="pcoded-item pcoded-left-item">
                                <li class="active">
                                    <a href="/" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i class="ti-home"></i><b>H</b></span>
                                        <span class="pcoded-mtext">Home</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/acomptes" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>AC</b></span>
                                        <span class="pcoded-mtext">Acompte</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/avenants" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>AV</b></span>
                                        <span class="pcoded-mtext">Avenant</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/chantiers" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>CA</b></span>
                                        <span class="pcoded-mtext">Chantier</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/chantierMateriels" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>CM</b></span>
                                        <span class="pcoded-mtext">Chantier-Matériel</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/chantierOverages" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>CO</b></span>
                                        <span class="pcoded-mtext">Chantier-Ouvrage</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/commandes" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>CO</b></span>
                                        <span class="pcoded-mtext">Commande</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/commandeMateriaus" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>CM</b></span>
                                        <span class="pcoded-mtext">Commande-matériau</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/consommationMateriels" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>CM</b></span>
                                        <span class="pcoded-mtext">Consommation matériel</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/decomptes" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>D</b></span>
                                        <span class="pcoded-mtext">Décompte </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/entretiens" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>EN</b></span>
                                        <span class="pcoded-mtext">Entretien </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/executions" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>EX</b></span>
                                        <span class="pcoded-mtext">Exécution </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/factures" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>FA</b></span>
                                        <span class="pcoded-mtext">Facture </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/fournisseurs" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>FO</b></span>
                                        <span class="pcoded-mtext">Fournisseur </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/frais" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>FR</b></span>
                                        <span class="pcoded-mtext">Frais </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/materiaus" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>MU</b></span>
                                        <span class="pcoded-mtext">Matériau </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/materiels" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>ML</b></span>
                                        <span class="pcoded-mtext">Matériel </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/operations" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>OP</b></span>
                                        <span class="pcoded-mtext">Opération </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/operationOverages" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>OO</b></span>
                                        <span class="pcoded-mtext">Opération-Ouvrage </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/ordreServices" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>OR</b></span>
                                        <span class="pcoded-mtext">Ordre de service </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/overages" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>OU</b></span>
                                        <span class="pcoded-mtext">Ouvrage </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/personnels" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>P</b></span>
                                        <span class="pcoded-mtext">Personnel </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/reparations" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>R</b></span>
                                        <span class="pcoded-mtext">Réparation </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>

                            <ul class="pcoded-item pcoded-left-item">
                                <li >
                                    <a href="/soutraitances" class="waves-effect waves-dark">
                                        <span class="pcoded-micon"><i ></i><b>S</b></span>
                                        <span class="pcoded-mtext">Sous traitance </span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                            </ul>
                            </div>
                        </div>
                    </nav>
                </div>


                    <div class="pcoded-content">
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="page-header-title">
                                            <h5 class="m-b-10">Gestion des données</h5>
                                            <p class="m-b-0"></p>
                                        </div>
                                    </div>  

                                    <div class="col-md-4">
                                    <ul class="breadcrumb"  >
                                            <li class="breadcrumb-item">
                                                <a href="/"> <i class="fa fa-home"></i> </a>
                                            </li> 
                                          <!--  <li class="breadcrumb-item">
                                                <a href="/#gestion" id="gestion"></i> Gestion des données</a>
                                            </li>     
                                            <li class="breadcrumb-item">
                                                <a href="/#edition"></i> Edition</a>
                                            </li>   -->                                   
                                        </ul>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    <!-- Warning Section Ends -->

    <script type="text/javascript" src=" <?php echo e(asset('assets/js/jquery/jquery.min.js')); ?> "></script>
    <script type="text/javascript" src=" <?php echo e(asset('assets/js/jquery-ui/jquery-ui.min.js')); ?> "></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/popper.js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap/js/bootstrap.min.js')); ?> "></script>
    <!-- waves js -->
    <script src="<?php echo e(asset('assets/pages/waves/js/waves.min.js')); ?>"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>

    <!-- slimscroll js -->
    <script src="<?php echo e(asset('assets/js/jquery.mCustomScrollbar.concat.min.js')); ?> "></script>

    <!-- menu js -->
    <script src="<?php echo e(asset('assets/js/pcoded.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vertical/vertical-layout.min.js')); ?> "></script>

    <script type="text/javascript" src="<?php echo e(asset('assets/js/script.js')); ?> "></script>

    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

</body>

</html>












































<!--
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">




    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">


    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

<style>
    /*
    DEMO STYLE
*/

@import  "https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700";
body {
    font-family: 'Poppins', sans-serif;
    background: #fafafa;
}

p {
    font-family: 'Poppins', sans-serif;
    font-size: 1.1em;
    font-weight: 300;
    line-height: 1.7em;
    color: #999;
}

a,
a:hover,
a:focus {
    color: inherit;
    text-decoration: none;
    transition: all 0.3s;
}

.navbar {
    padding: 15px 10px;
    background: #fff;
    border: none;
    border-radius: 0;
    margin-bottom: 40px;
    box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.1);
}

.navbar-btn {
    box-shadow: none;
    outline: none !important;
    border: none;
}


i,
span {
    display: inline-block;
}

/* ---------------------------------------------------
    SIDEBAR STYLE
----------------------------------------------------- */

.wrapper {
    display: flex;
    align-items: stretch;
}

#sidebar {
    min-width: 250px;
    max-width: 250px;
    background: #7386D5;
    color: #fff;
    transition: all 0.3s;
}

#sidebar.active {
    min-width: 80px;
    max-width: 80px;
    text-align: center;
}

#sidebar.active .sidebar-header h3,
#sidebar.active .CTAs {
    display: none;
}

#sidebar.active .sidebar-header strong {
    display: block;
}

#sidebar ul li a {
    text-align: left;
}

#sidebar.active ul li a {
    padding: 20px 10px;
    text-align: center;
    font-size: 0.85em;
}

#sidebar.active ul li a i {
    margin-right: 0;
    display: block;
    font-size: 1.8em;
    margin-bottom: 5px;
}

#sidebar.active ul ul a {
    padding: 10px !important;
}

#sidebar.active .dropdown-toggle::after {
    top: auto;
    bottom: 10px;
    right: 50%;
    -webkit-transform: translateX(50%);
    -ms-transform: translateX(50%);
    transform: translateX(50%);
}

#sidebar .sidebar-header {
    padding: 20px;
    background: #6d7fcc;
}

#sidebar .sidebar-header strong {
    display: none;
    font-size: 1.8em;
}

#sidebar ul.components {
    padding: 20px 0;
    border-bottom: 1px solid #47748b;
}

#sidebar ul li a {
    padding: 10px;
    font-size: 1.1em;
    display: block;
}

#sidebar ul li a:hover {
    color: #7386D5;
    background: #fff;
}

#sidebar ul li a i {
    margin-right: 10px;
}

#sidebar ul li.active>a,
a[aria-expanded="true"] {
    color: #fff;
    background: #6d7fcc;
}

a[data-toggle="collapse"] {
    position: relative;
}

.dropdown-toggle::after {
    display: block;
    position: absolute;
    top: 50%;
    right: 20px;
    transform: translateY(-50%);
}

ul ul a {
    font-size: 0.9em !important;
    padding-left: 30px !important;
    background: #6d7fcc;
}



/* ---------------------------------------------------
    CONTENT STYLE
----------------------------------------------------- */

#content {
    width: 100%;
    padding: 20px;
    min-height: 100vh;
    transition: all 0.3s;
}

/* ---------------------------------------------------
    MEDIAQUERIES
----------------------------------------------------- */

@media (max-width: 768px) {
    #sidebar {
        min-width: 80px;
        max-width: 80px;
        text-align: center;
        margin-left: -80px !important;
    }
    .dropdown-toggle::after {
        top: auto;
        bottom: 10px;
        right: 50%;
        -webkit-transform: translateX(50%);
        -ms-transform: translateX(50%);
        transform: translateX(50%);
    }
    #sidebar.active {
        margin-left: 0 !important;
    }
    #sidebar .sidebar-header h3 {
        display: none;
    }
    #sidebar .sidebar-header strong {
        display: block;
    }
    #sidebar ul li a {
        padding: 20px 10px;
    }
    #sidebar ul li a span {
        font-size: 0.85em;
    }
    #sidebar ul li a i {
        margin-right: 0;
        display: block;
    }
    #sidebar ul ul a {
        padding: 10px !important;
    }
    #sidebar ul li a i {
        font-size: 1.3em;
    }
    #sidebar {
        margin-left: 0;
    }
    #sidebarCollapse span {
        display: none;
    }
}
</style>
</head>

<body>

<div class="wrapper">

        <nav id="sidebar">
            <div class="sidebar-header">
                <h3></h3>
                <strong></strong>
            </div>

            <ul class="list-unstyled components">
                <li >
                    <a href="/">
                        Home
                    </a>
                </li>
                <li>
                    <a href="/acomptes" >
                        Acompte
                    </a>
                </li>
                <li>
                    <a href="/avenants" >
                        Avenant
                    </a>
                </li>
                <li>
                    <a href="/chantiers" >
                         Chantier
                    </a>
                </li>
                <li>
                    <a href="/commandes" >
                        Commande
                    </a>
                </li>
                <li>
                    <a href="/consommationMateriels" >
                        Consommation Matériel
                    </a>
                </li>
                <li>
                    <a href="/decomptes" >
                        Décompte
                    </a>
                </li>
                
                <li>
                    <a href="/entretiens" >
                        Entretien
                    </a>
                </li>
                <li>
                    <a href="/executions" >
                         Execution
                    </a>
                </li>
                <li>
                    <a href="/factures" >
                        Facture
                    </a>
                </li>
                <li>
                    <a href="/fournisseurs" >
                         Fournisseur
                    </a>
                </li>
                <li>
                    <a href="/frais" >
                        Frais
                    </a>
                </li>
                <li>
                    <a href="/materiaus" >
                        Matériaux
                    </a>
                </li>
                <li>
                    <a href="/materiels" >
                        Matériel
                    </a>
                    
                </li>
                <li>
                    <a href="/operations" >
                        Opération
                    </a>
                </li>
                <li>
                    <a href="/ordreServices" >
                        Ordre services
                    </a>
                </li>
                <li>
                    <a href="/overages" >
                        Ouvrage
                    </a>
                </li>
                <li class="active">
                    <a href="/personnels">
                        Personnel
                    </a>
                </li>
                <li>
                    <a href="/reparations" >
                        Réparation
                    </a>
                </li>
                <li>
                    <a href="/soutraitances" >
                        Sous traitance
                    </a>
                </li>     
            </ul>

        </nav>

      
        <div id="content">

            
            
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>


</body>

</html>

--><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>