
   
<?php $__env->startSection('content'); ?>
  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('fournisseurs.show',$fournisseur->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

  <div class="col d-flex justify-content-center" > 
 
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<!-- Alert si le code est dupliqué !-->
<?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 1): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un fournisseur avec ce code de fournisseur.<br><br>
            
        </div>
    <?php endif; ?>
  </div>

<!-- start Formulaire -->

<div class="col d-flex justify-content-center" > 
    <div class="card" style="width:50%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-edit"></i>  Modifier le fournisseur</h5>
        </div>
        <div class="card-block">

        <p style="font-weight:bold; margin-bottom : 30px;">Les champs avec <span class="text-danger">*</span> sont obligatoire.</p>

        <form class="form-material" action="<?php echo e(route('fournisseurs.update',$fournisseur->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
           
                <div class="form-group form-primary form-static-label">
                <label style="top: -14px; font-size: 13px; color: #448aff;">Code de fournisseur <span class="text-danger">*</span> </label>
                    <input type="number" name="code_fournisseur" value="<?php echo e($fournisseur->code_fournisseur); ?>" class="form-control" placeholder="Entrer le code de fournisseur">
                    <span class="form-bar"></span>
 </div>
                          
                  <div class="form-group form-primary form-static-label">
                  <label style="top: -14px; font-size: 13px; color: #448aff;">Intitulé de fournisseur <span class="text-danger">*</span> </label>
                    <input type="txt" name="intitule_fournisseur" value="<?php echo e($fournisseur->intitule_fournisseur); ?>" class="form-control" placeholder="Entrer l'intitulé de fournisseur">
                    <span class="form-bar"></span>
 </div>   
                
                <div class="form-group form-primary form-static-label">
                <label style="top: -14px; font-size: 13px; color: #448aff;">Télephone de fournisseur <span class="text-danger">*</span> </label>
                    <input type="number" name="telephone_fournisseur" value="<?php echo e($fournisseur->telephone_fournisseur); ?>" class="form-control" placeholder="Entrer le télephone de fournisseur">
                    <span class="form-bar"></span>
 </div>

                                
                <div class="form-group form-primary form-static-label">
                <label style="top: -14px; font-size: 13px; color: #448aff;">Email de fournisseur <span class="text-danger">*</span> </label>
                    <input type="email" name="email_fournisseur" value="<?php echo e($fournisseur->email_fournisseur); ?>" class="form-control" placeholder="Entrer l'email de fournisseur">
                    <span class="form-bar"></span>
</div>
        
                <div class=" text-right">
                    <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
                </div>
                                                 
            </form>
         </div>
    </div>
<!-- end formulaire -->

    <!-- formulaire 
    <div class="card">

<div class="card-header"><strong> Modifier la réparation</strong> </div>

    <div class="card-body">
        
        <div class="col-sm-8">

<form action="<?php echo e(route('fournisseurs.update',$fournisseur->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>

    <div class="row justify-content-around">
        <div class="col-6">
            <div class="form-group">
                <strong>Code : <span class="text-danger">*</span></strong>
                <input type="text" name="codefournisseur" value="<?php echo e($fournisseur->codefournisseur); ?>" class="form-control" placeholder="Code">
            </div>
        </div>

        <div class="col-6">
                <div class="form-group">
                    <strong>Intitulé : <span class="text-danger">*</span></strong>
                    <input type="text" class="form-control" name="intitulefournisseur" value="<?php echo e($fournisseur->intitulefournisseur); ?>" placeholder="Intitulé réparation">
                </div>
        </div>
    </div>

    <div class="row justify-content-around">
        <div class="col-6">
            <div class="form-group">
                <strong>Télephone : <span class="text-danger">*</span></strong>
                <input type="telephone" class="form-control" name="telephonefournisseur" value="<?php echo e($fournisseur->telephonefournisseur); ?>" placeholder="Télephone">
            </div>
        </div>
        
        <div class="col-6">
            <div class="form-group">
                <strong>Email : <span class="text-danger">*</span></strong>
                <input type="email" class="form-control" name="emailfournisseur" value="<?php echo e($fournisseur->emailfournisseur); ?>" placeholder="Email">
            </div>
        </div>
    </div>

<div class=" text-right">
        <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-edit"></i> Editer</button>
</div>
</div>

</form>
</div>
    </div>
</div>
!-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fournisseurs.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app\resources\views/fournisseurs/edit.blade.php ENDPATH**/ ?>