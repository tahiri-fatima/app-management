

  
  <?php $__env->startSection('content'); ?>
    
  <div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
      <a class="btn btn-primary" href="<?php echo e(route('chantiers.listeDecomptesChantier')); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
      <button class="btn btn-primary" type="button" onclick="PrintPage()" value="Imprimer" ><i class="fa fa-print" aria-hidden="true"></i>Imprimer</button>
     
  </div> 
  
  
  <div class="col d-flex justify-content-center" id="printableArea"> 
  
  <div style="width:90%" >
      <div class="card ">
  
      <div>
      <div class="text-center">
           <img class="img" src="<?php echo e(url('assets/images/logo.png')); ?>"  style="width: 170px; height: 70px; margin-top:25px " />

                      <h5 style="margin:30px 15px 30px 15px; text-align:center">Liste des décomptes du chantier <?php echo e($chantier->intitule_chantier); ?> </h5>
            </div>
                      <table class="table m-b-0 text-center" >
                            <thead style="font-weight:bold"> 
                                <td>Numéro de prix</td>       
                                <td>Designation d'opération</td>
                                <td>Quantité réalisée</td>
                                <td>Prix unitaire de revient</td>
                                <td>Montant HT </td>
                            </thead>

                            <tbody >
  
                            <?php $__currentLoopData = $decomptes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decompte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr >
                                        <td  rowspan = "<?php echo e($count); ?>" class="align-middle"  ><?php echo e($decompte->num_decompte); ?> </td>
                                <?php $__currentLoopData = $chantierOperationReels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                        <td ><?php echo e($operation->designation_operation); ?>  </td>
                                        <td> <?php echo e($operation->quantite_realisee); ?></td>
                                        <td > <?php echo e($operation->chantierOperation->prix_unitaire_revient); ?> </td>
                                        
                                        <td ><?php echo e($operation->montantHt); ?> </td>   
                                    </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td colspan="4" style="font-weight:bold">Total HT</td>
                            <td><?php echo e($chantier->totalHt); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="font-weight:bold">TVA 20%</td>
                            <td> <?php echo e($chantier->tva); ?> </td>
                        </tr>
                        <tr>
                            <td colspan="4" style="font-weight:bold">Total TTC</td>
                            <td> <?php echo e($chantier->totalTTC); ?> </td>
                        </tr>
                        <tr>
                            <td colspan="4" style="font-weight:bold">Total retenue</td>
                            <td> <?php echo e($chantier->tRetenue); ?> </td>
                        </tr>
                        <tr>
                            <td colspan="4" style="font-weight:bold">Total net</td>
                            <td> <?php echo e($chantier->totalNet); ?> </td>
                        </tr>
                        </tbody>
                      </table>   
  
                   </div>  
  
           
      </div>
  </div>
  
  
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/chantiers/getDecomptes.blade.php ENDPATH**/ ?>