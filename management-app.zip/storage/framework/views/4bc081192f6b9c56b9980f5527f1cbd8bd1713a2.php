
   
<?php $__env->startSection('content'); ?>


  
<div class="text-right" style="margin-bottom: 30px;margin-top: 20px;margin-right: 100px;"> 
            <a class="btn btn-primary" href="<?php echo e(route('operationOverages.showOperations',$ouvrage->id)); ?>" ><i class="fa fa-fw fa-arrow-circle-left"></i> Retour</a> 
</div> 

<div class="col d-flex justify-content-center" > 
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <!-- Alert si le code est dupliqué !-->
    <?php if(!empty(Session::get('error_code')) && Session::get('error_code') == 5): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> Il y a dejà un enregistrement avec ce code ce couple de code opération et ouvrage.<br><br>
            
        </div>
    <?php endif; ?>


</div>


<!-- start Formulaire -->

<div class="col d-flex justify-content-center" >

    <div class="card" style="width:90%">  
        <div class="card-header">
            <h5><i class="fa fa-fw fa-plus-circle"></i>  Modifier les opérations d'ouvrage</h5>
        </div>
        <div class="card-block">
            <form class="form-material" action="<?php echo e(route('operationOverages.updateOperations', $ouvrage->id)); ?>"  enctype="multipart/form-data" onsubmit="return verifierChampsOuvrage()" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row justify-content-around" style="margin-bottom: 20px; ">
                <div class="col-6">
                    <div class="form-group form-primary form-static-label">
                    <label class="form-label " style="top: -14px; font-size: 11px; color: #448aff;">Ouvrage <span class="text-danger">*</span> </label>
                        <div class="select">
                            <select class="form-control" name="overage_id" >
                            <option value="<?php echo e($ouvrage->id); ?>"><?php echo e($ouvrage->designation_ouvrage); ?></option>
                                <?php $__currentLoopData = $ouvrages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ouvrage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ouvrage->id); ?>"><?php echo e($ouvrage->designation_ouvrage); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>                
                        <span class="form-bar"></span>   
                    </div>
                </div>

                <div class="col-6">
                    <div class="multi-select" >
                        <label  style="top: -14px; color: black;">Opérations <span class="text-danger">*</span> </label>
                        <div class="select" >
                            <select id="mySelect" class="operations" name="operations[]" multiple size="5" style="width: 100%;" >
                                <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(in_array($operation->id , $ops)): ?>
                                        <option value="<?php echo e($operation->id); ?>" selected="true"> <?php echo e($operation->designation_operation); ?>  </option>
                                    <?php else: ?>
                                        <option value="<?php echo e($operation->id); ?>"> <?php echo e($operation->designation_operation); ?>  </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>                                                                   
                    </div>
                </div>
            </div>

            

            
                
                    <h5>Liste des opérations :</h5>
                    <table class="table m-b-0 text-center">
                        <thead>
                            <td>Opération</td>
                            <td>Code opération</td>
                            <td>Prix Unitaire</td>
                            <td>Quantité</td>
                            <td>Taux d'ajustement</td>
                            <td>Montant net</td>
                        </thead>
                        <tbody >
                        <?php $k=1; ?>
                            <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="display:none;" id="<?php echo e($operation->id); ?>" class="data">
                                    <td > <?php echo e($operation->designation_operation); ?> </td>
                                    <td> <input type="text" class="text-center"  name="code_operation[]" value="<?php echo e($operation->code_operation); ?>" style="border:none;" readonly> </td>
                                    <td> <input type="text" class="text-center" id="prix<?php echo e($operation->id); ?>"  name="prix_unitaire" value="<?php echo e($operation->prix_unitaire); ?>" 
                                    style="border:none;" readonly> </td>
                                    <?php if(in_array($operation->id , $ops)): ?>
                                    <td > <input type="number" 
                                    data-container="body" data-toggle="popover"  data-placement="bottom" data-content="Le champ quantité est obligatoire!"
                                    class="quantite text-center" id="q<?php echo e($operation->id); ?>" name="quantite_operation[]" style="border:none;" 
                                    placeholder="Entrer la quantité" value= "<?php echo e($ops[$k]); ?>" onchange="recupValeurOuv(this.value, this.id);"  > </td>

                                    <td > <input type="number"
                                    data-container="body" data-toggle="popover"  data-placement="bottom" data-content="Le champ taux d'ajustement est obligatoire!"
                                    class="taux text-center" id="t<?php echo e($operation->id); ?>" name="taux_ajustement[]" style="border:none;" 
                                    placeholder="Entrer le taux d'ajustement" value= "<?php echo e($ops[$k+1]); ?>"   onchange="recupValeurOuv(this.value, this.id);"  > </td>

                                    <td ><input type="decimal" class="montant text-center" id="montant<?php echo e($operation->id); ?>" name="montant_net[]" value="0" style="border:none;" 
                                    value= "<?php echo e($ops[$k+2]); ?>" readonly></td>

                                    <?php $k+=4; ?>
                                    <?php else: ?>
                                    <td > <input type="number" 
                                    data-container="body" data-toggle="popover"  data-placement="bottom" data-content="Le champ quantité est obligatoire!"
                                    class="quantite text-center" id="q<?php echo e($operation->id); ?>" name="quantite_operation[]" style="border:none;" placeholder="Entrer la quantité"
                                      value= "" onchange="recupValeurOuv(this.value, this.id);"> </td>

                                    <td > <input type="number"
                                    data-container="body" data-toggle="popover"  data-placement="bottom" data-content="Le champ taux d'ajustement est obligatoire!"
                                     class="taux text-center" id="t<?php echo e($operation->id); ?>" name="taux_ajustement[]" style="border:none;"
                                     placeholder="Entrer le taux d'ajustement" value= "" onchange="recupValeurOuv(this.value, this.id);"  > </td>

                                    <td ><input type="decimal" class="montant text-center" id="montant<?php echo e($operation->id); ?>" name="montant_net[]" value="0" style="border:none;"  value= "" readonly></td>

                                     <?php endif; ?>                                    
                                    
                                    
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr>
                                    <td colspan="5" style="text-align:center;" >Total</td>
                                    <td ><input type="decimal" class="text-center" name="total_ouvrage" value="0" style="border:none;" id="total" readonly></td>
                                </tr>
                        </tbody>
                    </table>
                   
                <div class=" text-right" style="margin-top: 10px;">
                    <button type="submit" class="btn btn-primary"> <i class="fa fa-fw fa-plus-circle" > </i> Modifier</button>
                    <button type="reset" class="btn btn-info" style="margin-left: 10px;"><i class="fa fa-fw fa-sync" ></i> Réinitialiser</button>
                </div>
                                                 
            </form>

            

         </div>
    </div>    
</div>

<!-- end Formulaire -->


























<?php $__env->stopSection(); ?>
<?php echo $__env->make('operationOverages.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\management-app-v6\management-app\resources\views/operationOverages/edit.blade.php ENDPATH**/ ?>